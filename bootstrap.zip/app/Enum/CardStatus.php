<?php

namespace App\Enum;

enum CardStatus: int
{
    case APPROVED = 1;
    case PENDING = 0;
}
