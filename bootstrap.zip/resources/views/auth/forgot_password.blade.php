@extends('auth.layout.master')
@section('content')
    <div class="container">
        <div class="row">
            <div class="bg-white shadow-lg col-md-6 offset-md-3 col-12 mt-100 p-5">
                <div class=" rounded10 ">
                    <div class="content-top-agile p-20 pb-0">
                        <a href="/"><img width="100" src="{{ asset(env('APP_LOGO_DARK')) }}"
                                alt="{{ env('APP_NAME') }}">
                        </a>
                        <br>
                        <h3 class="text-primary">Forgot Your Password?</h3>
                        <p class="mb-0">We get it, stuff happens. Just enter your email address below and we'll
                            send you a link to reset your password!</p>
                    </div>
                    <div class="p-40">
                        <form class="user" method="POST" action="{{ route('password.email') }}">
                            @csrf
                            <div class="form-group">
                                <input type="email" class="form-control form-control-user" id="exampleInputEmail"
                                    name="email" placeholder="Enter account email address" value="{{ old('email') }}"
                                    required autofocus>
                                @if ($errors->has('email'))
                                    <p class="text-danger">{{ $errors->first('email') }}</p>
                                @endif
                            </div>
                            <button type="submit" class="btn btn-primary btn-user btn-block mt-5">
                                Email Password Reset Link
                            </button>
                        </form>
                        <div class="text-center">
                            <p class="mt-15 mb-0 text-primary">Don't have an account? <a href="{{ route('register') }}"
                                    class="text-warning ms-5">Register account</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
