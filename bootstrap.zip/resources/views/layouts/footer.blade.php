<footer class="footer-wrapper">
            <div class="footer-container container">
                <div class="footer-column three columns" id="footer-widget-1">
                    <div id="text-5" class="widget widget_text greennature-item greennature-widget">
                        <div class="textwidget">
                            <p><img src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/logo-light.png"
                                    style="width: 170px;" alt="" /></p>
                            <p>{{ config('app.name') }} empowers individuals to live sustainably by rewarding eco-friendly actions with
                                cryptocurrency. Join our movement to create a greener planet!</p>
                        </div>
                    </div>
                </div>
                <div class="footer-column three columns" id="footer-widget-2">
                    <div id="text-9" class="widget widget_text greennature-item greennature-widget">
                        <h3 class="greennature-widget-title">Contact Info</h3>
                        <div class="clear"></div>
                        <div class="textwidget"><span class="clear"></span><span class="greennature-space"
                                style="margin-top: -6px; display: block;"></span>
                            Address: 184 Main Collins Street West Victoria 8007
                            <span class="clear"></span><span class="greennature-space"
                                style="margin-top: 10px; display: block;"></span>
                            <i class="greennature-icon fa fa-phone"
                                style="vertical-align: middle; color: #fff; font-size: 16px;"></i> +1800-222-3333
                            <span class="clear"></span><span class="greennature-space"
                                style="margin-top: 10px; display: block;"></span>
                            <i class="greennature-icon fa fa-mobile"
                                style="vertical-align: middle; color: #fff; font-size: 20px;"></i> +1833-232-3443
                            <span class="clear"></span><span class="greennature-space"
                                style="margin-top: 10px; display: block;"></span>
                            <i class="greennature-icon fa fa-envelope-o"
                                style="vertical-align: middle; color: #fff; font-size: 16px;"></i> <a
                                href="https://demo.goodlayers.com/cdn-cgi/l/email-protection" class="__cf_email__"
                                data-cfemail="177638392336342357302532323939362322253220277934383a">[email
                                protected]</a>
                        </div>
                    </div>
                </div>
                <div class="footer-column three columns" id="footer-widget-3">
                    <div id="gdlr-recent-post-widget-5"
                        class="widget widget_gdlr-recent-post-widget greennature-item greennature-widget">
                        <h3 class="greennature-widget-title">Recent Posts</h3>
                        <div class="clear"></div>
                        <div class="greennature-recent-post-widget">
                            <div class="recent-post-widget">
                                <div class="recent-post-widget-thumbnail"><a
                                        href="https://demo.goodlayers.com/greennature/2014/03/21/sem-porta-mollis-parturient/"><img
                                            src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_294481373-150x150.jpg"
                                            alt="" width="150" height="150" /></a></div>
                                <div class="recent-post-widget-content">
                                    <div class="recent-post-widget-title"><a
                                            href="https://demo.goodlayers.com/greennature/2014/03/21/sem-porta-mollis-parturient/">Eco
                                            Coin's Global Impact</a></div>
                                    <div class="recent-post-widget-info">
                                        <div class="blog-info blog-date greennature-skin-info"><i
                                                class="fa fa-clock-o"></i><a
                                                href="https://demo.goodlayers.com/greennature/2014/03/21/">21 Mar
                                                2014</a></div>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            <div class="recent-post-widget">
                                <div class="recent-post-widget-thumbnail"><a
                                        href="https://demo.goodlayers.com/greennature/2014/03/21/nullam-lorem-mattis-purus/"><img
                                            src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_181393724-150x150.jpg"
                                            alt="" width="150" height="150" /></a></div>
                                <div class="recent-post-widget-content">
                                    <div class="recent-post-widget-title"><a
                                            href="https://demo.goodlayers.com/greennature/2014/03/21/nullam-lorem-mattis-purus/">Top
                                            Eco Warriors</a></div>
                                    <div class="recent-post-widget-info">
                                        <div class="blog-info blog-date greennature-skin-info"><i
                                                class="fa fa-clock-o"></i><a
                                                href="https://demo.goodlayers.com/greennature/2014/03/21/">21 Mar
                                                2014</a></div>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="footer-column three columns" id="footer-widget-4">
                    <div id="gdlr-recent-portfolio2-widget-6"
                        class="widget widget_gdlr-recent-portfolio2-widget greennature-item greennature-widget">
                        <h3 class="greennature-widget-title">Recent Eco Actions</h3>
                        <div class="clear"></div>
                        <div class="greennature-recent-port2-widget">
                            <div class="recent-port-widget-thumbnail"><a
                                    href="https://demo.goodlayers.com/greennature/portfolio/wind-energy/"><img
                                        src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_161515241-150x150.jpg"
                                        alt="" width="150" height="150" /></a></div>
                            <div class="recent-port-widget-thumbnail"><a
                                    href="https://demo.goodlayers.com/greennature/portfolio/elephant-sanctuary/"><img
                                        src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_133689230-150x150.jpg"
                                        alt="" width="150" height="150" /></a></div>
                            <div class="recent-port-widget-thumbnail"><a
                                    href="https://demo.goodlayers.com/greennature/portfolio/conservation-volunteering/"><img
                                        src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_53600221-150x150.jpg"
                                        alt="" width="150" height="150" /></a></div>
                            <div class="recent-port-widget-thumbnail"><a
                                    href="https://demo.goodlayers.com/greennature/portfolio/engery-conservation/"><img
                                        src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_124871620-150x150.jpg"
                                        alt="" width="150" height="150" /></a></div>
                            <div class="recent-port-widget-thumbnail"><a
                                    href="https://demo.goodlayers.com/greennature/portfolio/video-inside-this-post/"><img
                                        src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_281995004-150x150.jpg"
                                        alt="" width="150" height="150" /></a></div>
                            <div class="recent-port-widget-thumbnail"><a
                                    href="https://demo.goodlayers.com/greennature/portfolio/kids-can-volunteer/"><img
                                        src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_256181956-150x150.jpg"
                                        alt="" width="150" height="150" /></a></div>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="copyright-wrapper">
                <div class="copyright-container container">
                    <div class="copyright-left">
                        <a href="https://facebook.com/goodlayers"><i class="greennature-icon fa fa-facebook"
                                style="vertical-align: middle;color: #bbbbbb;font-size: 20px"></i></a>
                        <a href="https://twitter.com/goodlayers"><i class="greennature-icon fa fa-twitter"
                                style="vertical-align: middle;color: #bbbbbb;font-size: 20px"></i></a>
                        <a href="#"><i class="greennature-icon fa fa-dribbble"
                                style="vertical-align: middle;color: #bbbbbb;font-size: 20px"></i></a>
                        <a href="#"><i class="greennature-icon fa fa-pinterest"
                                style="vertical-align: middle;color: #bbbbbb;font-size: 20px"></i></a>
                        <a href="#"><i class="greennature-icon fa fa-google-plus"
                                style="vertical-align: middle;color: #bbbbbb;font-size: 20px"></i></a>
                        <a href="#"><i class="greennature-icon fa fa-instagram"
                                style="vertical-align: middle;color: #bbbbbb;font-size: 20px"></i></a>
                    </div>
                    
                    <div class="copyright-right">
                        Copyright 2016 {{ config('app.name') }}, All Rights Reserved
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </footer>
        @include('layouts.partials.payment-box')