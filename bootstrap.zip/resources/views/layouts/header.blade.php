<header class="greennature-header-wrapper header-style-5-wrapper greennature-header-with-top-bar">
    <!-- top navigation -->
    <div class="top-navigation-wrapper">
        <div class="top-navigation-container container">
            <div class="top-navigation-left">
                <div class="top-navigation-left-text">
                    Phone : +1800-222-3333      Email : <a
                        href="https://demo.goodlayers.com/cdn-cgi/l/email-protection" class="__cf_email__"
                        data-cfemail="a9cac6c7ddc8cadde9cedbccccc7c7c8dddcdbccded987cac6c4">[email&#160;protected]</a>
                </div>
            </div>
            <div class="top-navigation-right">
                <div class="top-social-wrapper">
                    <div class="social-icon">
                        <a href="#" target="_blank">
                            <i class="fa fa-facebook"></i></a>
                    </div>
                    <div class="social-icon">
                        <a href="#" target="_blank">
                            <i class="fa fa-flickr"></i></a>
                    </div>
                    <div class="social-icon">
                        <a href="#" target="_blank">
                            <i class="fa fa-linkedin"></i></a>
                    </div>
                    <div class="social-icon">
                        <a href="#" target="_blank">
                            <i class="fa fa-pinterest-p"></i></a>
                    </div>
                    <div class="social-icon">
                        <a href="#" target="_blank">
                            <i class="fa fa-tumblr"></i></a>
                    </div>
                    <div class="social-icon">
                        <a href="#" target="_blank">
                            <i class="fa fa-twitter"></i></a>
                    </div>
                    <div class="social-icon">
                        <a href="#" target="_blank">
                            <i class="fa fa-vimeo"></i></a>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <div id="greennature-header-substitute"></div>
    <div class="greennature-header-inner header-inner-header-style-5">
        <div class="greennature-header-container container">
            <div class="greennature-header-inner-overlay"></div>
            <!-- logo -->
            <div class="greennature-logo">
                <div class="greennature-logo-inner">
                    <a href="/">
                        <img src="{{ config('app.logo') }}" alt="" /> </a>
                </div>
                <div class="greennature-responsive-navigation dl-menuwrapper"
                    id="greennature-responsive-navigation"><button class="dl-trigger">Open Menu</button>
                    <ul id="menu-main-menu" class="dl-menu greennature-main-mobile-menu">
                        <li id="menu-item-5855"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-5680 current_page_item menu-item-5855">
                            <a href="https://demo.goodlayers.com/greennature/" aria-current="page">Home</a>
                        </li>
                        <li id="menu-item-15"
                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-15">
                            <a href="#">Pages</a>
                            <ul class="dl-submenu">
                                <li id="menu-item-14"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-14">
                                    <a href="#">Features</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5630"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5630">
                                            <a href="https://demo.goodlayers.com/greennature/custom-skin/">Custom
                                                Skin</a>
                                        </li>
                                        <li id="menu-item-5629"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5629">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/sidebar-size-customizable/">Sidebar
                                                Size Customizable</a>
                                        </li>
                                        <li id="menu-item-5642"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5642">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/scalable-container/">Scalable
                                                Container</a>
                                        </li>
                                        <li id="menu-item-5623"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5623">
                                            <a href="https://demo.goodlayers.com/greennature/post-format/">Post
                                                Format</a>
                                        </li>
                                        <li id="menu-item-5624"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5624">
                                            <a href="https://demo.goodlayers.com/greennature/google-font/">Google
                                                Font</a>
                                        </li>
                                        <li id="menu-item-5625"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5625">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/unlimited-sidebar/">Unlimited
                                                Sidebar</a>
                                        </li>
                                        <li id="menu-item-5626"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5626">
                                            <a href="https://demo.goodlayers.com/greennature/font-uploader/">Font
                                                Uploader</a>
                                        </li>
                                        <li id="menu-item-5622"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5622">
                                            <a href="https://demo.goodlayers.com/greennature/layer-slider-2/">Master
                                                Slider</a>
                                        </li>
                                        <li id="menu-item-5628"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5628">
                                            <a href="https://demo.goodlayers.com/greennature/font-awesome/">Font
                                                Awesome</a>
                                        </li>
                                        <li id="menu-item-5621"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5621">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/optimized-code-seo/">Optimized
                                                Code &#038; SEO</a>
                                        </li>
                                        <li id="menu-item-5627"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5627">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/shortcode-generator/">Shortcode
                                                Generator</a>
                                        </li>
                                        <li id="menu-item-5657"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5657">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/visual-editor-in-page-builder-2/">Visual
                                                Editor in Page Builder</a>
                                        </li>
                                    </ul>
                                </li>
                                <li id="menu-item-5976"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5976">
                                    <a href="https://demo.goodlayers.com/greennature/act-now/">Act Now</a>
                                </li>
                                <li id="menu-item-5948"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5948">
                                    <a href="https://demo.goodlayers.com/greennature/about-1/">About Us 1</a>
                                </li>
                                <li id="menu-item-5947"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5947">
                                    <a href="https://demo.goodlayers.com/greennature/about-2/">About Us 2</a>
                                </li>
                                <li id="menu-item-5946"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5946">
                                    <a href="https://demo.goodlayers.com/greennature/service/">Service</a>
                                </li>
                                <li id="menu-item-5662"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5662">
                                    <a
                                        href="https://demo.goodlayers.com/greennature/personnel-2/">Personnel</a>
                                </li>
                                <li id="menu-item-5661"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5661">
                                    <a href="https://demo.goodlayers.com/greennature/qa/">Q&#038;A</a>
                                </li>
                                <li id="menu-item-5644"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5644">
                                    <a href="https://demo.goodlayers.com/greennature/contact-page/">Contact
                                        Page
                                        1</a>
                                </li>
                                <li id="menu-item-5643"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5643">
                                    <a href="https://demo.goodlayers.com/greennature/contact-page-2/">Contact
                                        Page 2</a>
                                </li>
                                <li id="menu-item-12"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-12">
                                    <a href="https://demo.goodlayers.com/greennature/404error">404 Page</a>
                                </li>
                                <li id="menu-item-5594"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5594">
                                    <a
                                        href="https://demo.goodlayers.com/greennature/testimonial/">Testimonial</a>
                                </li>
                                <li id="menu-item-5672"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5672">
                                    <a
                                        href="https://demo.goodlayers.com/greennature/gallery-3-columns-without-caption/">Gallery</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5771"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5771">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/gallery-2-columns-without-caption/">Gallery
                                                2 Columns Without Caption</a>
                                        </li>
                                        <li id="menu-item-5772"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5772">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/gallery-2-columns-with-caption/">Gallery
                                                2 Columns With Caption</a>
                                        </li>
                                        <li id="menu-item-5669"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5669">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/gallery-3-columns-without-caption/">Gallery
                                                3 Columns Without Caption</a>
                                        </li>
                                        <li id="menu-item-5773"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5773">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/gallery-3-columns-with-caption/">Gallery
                                                3 Columns With Caption</a>
                                        </li>
                                        <li id="menu-item-5770"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5770">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/gallery-4-columns-without-caption/">Gallery
                                                4 Columns Without Caption</a>
                                        </li>
                                        <li id="menu-item-5769"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5769">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/gallery-4-columns-with-caption/">Gallery
                                                4 Columns With Caption</a>
                                        </li>
                                        <li id="menu-item-5768"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5768">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/gallery-5-columns-without-caption/">Gallery
                                                5 Columns Without Caption</a>
                                        </li>
                                        <li id="menu-item-5767"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5767">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/gallery-5-columns-with-caption/">Gallery
                                                5 Columns With Caption</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li id="menu-item-5654"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5654">
                            <a
                                href="https://demo.goodlayers.com/greennature/portfolio-grid-3-columns-no-space/">Portfolio</a>
                            <ul class="dl-submenu">
                                <li id="menu-item-5547"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5547">
                                    <a
                                        href="https://demo.goodlayers.com/greennature/portfolio-grid-3-columns/">Portfolio
                                        Classic</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5581"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5581">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-1-column/">Portfolio
                                                Grid 1 Column (Both Sidebar)</a>
                                        </li>
                                        <li id="menu-item-5583"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5583">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-2-columns/">Portfolio
                                                Grid 2 Columns (Right Sidebar)</a>
                                        </li>
                                        <li id="menu-item-5568"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5568">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-3-columns/">Portfolio
                                                Grid 3 Columns</a>
                                        </li>
                                        <li id="menu-item-5582"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5582">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-4-columns/">Portfolio
                                                Grid 4 Columns</a>
                                        </li>
                                        <li id="menu-item-5647"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5647">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-2-columns-no-space/">Portfolio
                                                Grid 2 Columns, No Space</a>
                                        </li>
                                        <li id="menu-item-5646"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5646">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-3-columns-no-space/">Portfolio
                                                Grid 3 Columns, No Space</a>
                                        </li>
                                        <li id="menu-item-5645"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5645">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-4-columns-no-space/">Portfolio
                                                Grid 4 Columns, No Space</a>
                                        </li>
                                    </ul>
                                </li>
                                <li id="menu-item-5658"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5658">
                                    <a
                                        href="https://demo.goodlayers.com/greennature/portfolio-modern-3-columns/">Portfolio
                                        Modern</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5580"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5580">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-modern-3-columns/">Portfolio
                                                Modern 3 Columns</a>
                                        </li>
                                        <li id="menu-item-5579"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5579">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-modern-4-columns/">Portfolio
                                                Modern 4 Columns</a>
                                        </li>
                                        <li id="menu-item-5649"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5649">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-modern-3-columns-no-space/">Portfolio
                                                Modern 3 Columns, No Space</a>
                                        </li>
                                        <li id="menu-item-5648"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5648">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-modern-4-columns-no-space/">Portfolio
                                                Modern 4 Columns, No Space</a>
                                        </li>
                                        <li id="menu-item-5663"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5663">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-fixed-masonry-style-1/">Portfolio
                                                Fixed Masonry Style 1</a>
                                        </li>
                                        <li id="menu-item-5664"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5664">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-fixed-masonry-style-2/">Portfolio
                                                Fixed Masonry Style 2</a>
                                        </li>
                                    </ul>
                                </li>
                                <li id="menu-item-5659"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5659">
                                    <a
                                        href="https://demo.goodlayers.com/greennature/portfolio-modern-3-columns-with-filter/">Portfolio
                                        With Filter</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5584"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5584">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-1-columns-with-filter/">Portfolio
                                                Grid 1 Col With Filter</a>
                                        </li>
                                        <li id="menu-item-5585"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5585">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-2-columns-with-filter/">Portfolio
                                                Grid 2 Cols With Filter</a>
                                        </li>
                                        <li id="menu-item-5586"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5586">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-3-columns-with-filter/">Portfolio
                                                Grid 3 Cols With Filter</a>
                                        </li>
                                        <li id="menu-item-5587"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5587">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-grid-4-columns-with-filter/">Portfolio
                                                Grid 4 Cols With Filter</a>
                                        </li>
                                        <li id="menu-item-5588"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5588">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-modern-3-columns-with-filter/">Portfolio
                                                Modern 3 Cols With Filter</a>
                                        </li>
                                        <li id="menu-item-5589"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5589">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/portfolio-modern-4-columns-with-filter/">Portfolio
                                                Modern 4 Cols With Filter</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li id="menu-item-5546"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5546">
                            <a
                                href="https://demo.goodlayers.com/greennature/blog-full-with-right-sidebar/">Blog</a>
                            <ul class="dl-submenu">
                                <li id="menu-item-5"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-5">
                                    <a href="#">Blog Full</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5578"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5578">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-full-with-right-sidebar/">Blog
                                                Full With Right Sidebar</a>
                                        </li>
                                        <li id="menu-item-5577"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5577">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-full-with-left-sidebar/">Blog
                                                Full With Left Sidebar</a>
                                        </li>
                                        <li id="menu-item-5576"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5576">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-full-with-both-sidebar/">Blog
                                                Full With Both Sidebar</a>
                                        </li>
                                    </ul>
                                </li>
                                <li id="menu-item-6"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-6">
                                    <a href="#">Blog Column</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5569"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5569">
                                            <a href="https://demo.goodlayers.com/greennature/blog-1-column/">Blog
                                                1 Column (Right Sidebar)</a>
                                        </li>
                                        <li id="menu-item-5570"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5570">
                                            <a href="https://demo.goodlayers.com/greennature/blog-2-columns/">Blog
                                                2 Columns (Right Sidebar)</a>
                                        </li>
                                        <li id="menu-item-5572"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5572">
                                            <a href="https://demo.goodlayers.com/greennature/blog-3-columns/">Blog
                                                3 Columns</a>
                                        </li>
                                        <li id="menu-item-5574"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5574">
                                            <a href="https://demo.goodlayers.com/greennature/blog-4-columns/">Blog
                                                4 Columns</a>
                                        </li>
                                    </ul>
                                </li>
                                <li id="menu-item-7"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-7">
                                    <a href="#">Blog Masonry</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5571"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5571">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-2-columns-masonry/">Blog
                                                2 Columns &#8211; Masonry (Right Sidebar)</a>
                                        </li>
                                        <li id="menu-item-5573"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5573">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-3-columns-masonry/">Blog
                                                3 Columns – Masonry</a>
                                        </li>
                                        <li id="menu-item-5575"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5575">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-4-columns-masonry/">Blog
                                                4 Columns – Masonry</a>
                                        </li>
                                    </ul>
                                </li>
                                <li id="menu-item-13"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-13">
                                    <a href="#">Blog Medium</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5653"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5653">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-medium-with-right-sidebar/">Blog
                                                Medium With Right Sidebar</a>
                                        </li>
                                        <li id="menu-item-5652"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5652">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-medium-with-left-sidebar/">Blog
                                                Medium With Left Sidebar</a>
                                        </li>
                                        <li id="menu-item-5651"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5651">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-medium-with-both-sidebar/">Blog
                                                Medium With Both Sidebar</a>
                                        </li>
                                        <li id="menu-item-5650"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5650">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/blog-medium-without-sidebar/">Blog
                                                Medium Without Sidebar</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li id="menu-item-6040"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-6040">
                            <a href="https://demo.goodlayers.com/greennature/woocommerce-shop/">Shop</a>
                            <ul class="dl-submenu">
                                <li id="menu-item-6034"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6034">
                                    <a href="https://demo.goodlayers.com/greennature/woocommerce-shop/">WooCommerce
                                        Shop</a>
                                </li>
                                <li id="menu-item-6039"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6039">
                                    <a href="https://demo.goodlayers.com/greennature/shop/">Shop</a>
                                </li>
                                <li id="menu-item-6038"
                                    class="menu-item menu-item-type-post_type menu-item-object-product menu-item-6038">
                                    <a
                                        href="https://demo.goodlayers.com/greennature/product/classy-men-shoes/">Single
                                        Product</a>
                                </li>
                                <li id="menu-item-6035"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6035">
                                    <a href="https://demo.goodlayers.com/greennature/cart/">Cart</a>
                                </li>
                                <li id="menu-item-6036"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6036">
                                    <a href="https://demo.goodlayers.com/greennature/checkout/">Checkout</a>
                                </li>
                                <li id="menu-item-6037"
                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6037">
                                    <a href="https://demo.goodlayers.com/greennature/my-account/">My
                                        Account</a>
                                </li>
                            </ul>
                        </li>
                        <li id="menu-item-5641"
                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5641">
                            <a href="https://demo.goodlayers.com/greennature/typography/">Shortcodes</a>
                            <ul class="dl-submenu">
                                <li id="menu-item-8"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-8">
                                    <a href="#">Shortcode Set 1</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5548"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5548">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/accordiontoggle-box/">Accordion/Toggle
                                                Box</a>
                                        </li>
                                        <li id="menu-item-5567"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5567">
                                            <a href="https://demo.goodlayers.com/greennature/audio-shortcode/">Audio
                                                Shortcode</a>
                                        </li>
                                        <li id="menu-item-5549"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5549">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/button/">Button</a>
                                        </li>
                                        <li id="menu-item-5592"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5592">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/column-shortcode/">Column
                                                Shortcode</a>
                                        </li>
                                        <li id="menu-item-5552"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5552">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/divider/">Divider</a>
                                        </li>
                                        <li id="menu-item-5563"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5563">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/gallery-shortcode/">Gallery
                                                Shortcode</a>
                                        </li>
                                    </ul>
                                </li>
                                <li id="menu-item-9"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9">
                                    <a href="#">Shortcode Set 2</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5560"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5560">
                                            <a href="https://demo.goodlayers.com/greennature/heading-tag/">Heading
                                                Tag</a>
                                        </li>
                                        <li id="menu-item-5562"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5562">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/icons-icon-boxes/">icons
                                                &#038; icon boxes</a>
                                        </li>
                                        <li id="menu-item-5565"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5565">
                                            <a href="https://demo.goodlayers.com/greennature/lightbox-frames/">Lightbox
                                                &#038; Frames</a>
                                        </li>
                                        <li id="menu-item-5556"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5556">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/notification-boxes/">Notification
                                                Boxes</a>
                                        </li>
                                        <li id="menu-item-5553"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5553">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/personnel/">Personnel</a>
                                        </li>
                                        <li id="menu-item-5591"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5591">
                                            <a href="https://demo.goodlayers.com/greennature/post-slider/">Post
                                                Slider</a>
                                        </li>
                                    </ul>
                                </li>
                                <li id="menu-item-10"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10">
                                    <a href="#">Shortcode Set 3</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5595"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5595">
                                            <a href="https://demo.goodlayers.com/greennature/price-table/">Price
                                                Table</a>
                                        </li>
                                        <li id="menu-item-5593"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5593">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/process/">Process</a>
                                        </li>
                                        <li id="menu-item-5557"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5557">
                                            <a href="https://demo.goodlayers.com/greennature/progress-circle/">Progress
                                                Circle</a>
                                        </li>
                                        <li id="menu-item-5558"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5558">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/skills/">Skills</a>
                                        </li>
                                        <li id="menu-item-5590"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5590">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/slider-shortcode/">Slider
                                                Shortcode</a>
                                        </li>
                                        <li id="menu-item-5561"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5561">
                                            <a href="https://demo.goodlayers.com/greennature/space/">Space</a>
                                        </li>
                                    </ul>
                                </li>
                                <li id="menu-item-11"
                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-11">
                                    <a href="#">Shortcode Set 4</a>
                                    <ul class="dl-submenu">
                                        <li id="menu-item-5550"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5550">
                                            <a href="https://demo.goodlayers.com/greennature/styled-box/">Styled
                                                Box</a>
                                        </li>
                                        <li id="menu-item-5559"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5559">
                                            <a href="https://demo.goodlayers.com/greennature/stunning-text/">Stunning
                                                Text</a>
                                        </li>
                                        <li id="menu-item-5564"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5564">
                                            <a href="https://demo.goodlayers.com/greennature/table/">Table</a>
                                        </li>
                                        <li id="menu-item-5555"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5555">
                                            <a href="https://demo.goodlayers.com/greennature/tabs/">Tabs</a>
                                        </li>
                                        <li id="menu-item-5554"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5554">
                                            <a href="https://demo.goodlayers.com/greennature/testimonial-2/">Testimonial
                                                &#038; Quote</a>
                                        </li>
                                        <li id="menu-item-5551"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5551">
                                            <a
                                                href="https://demo.goodlayers.com/greennature/typography/">Typography</a>
                                        </li>
                                        <li id="menu-item-5566"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5566">
                                            <a href="https://demo.goodlayers.com/greennature/video/">Video</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- navigation -->
            @include('layouts.navbar')
            <div class="clear"></div>
        </div>
    </div>
</header>