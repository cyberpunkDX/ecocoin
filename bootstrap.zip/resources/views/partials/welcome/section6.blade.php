<section id="content-section-6">
                <div class="greennature-color-wrapper" style="background-color: #ffffff;">
                    <div class="container">
                        <div class="four columns">
                            <div
                                class="greennature-item-title-wrapper greennature-item greennature-left-divider greennature-small">
                                <div class="greennature-item-title-container container">
                                    <div class="greennature-item-title-head">
                                        <h3
                                            class="greennature-item-title greennature-skin-title greennature-skin-border">
                                            Eco News</h3><a class="greennature-item-title-link"
                                            href="https://demo.goodlayers.com/greennature/blog-full-with-right-sidebar/">Read
                                            All News</a>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="blog-item-wrapper">
                                <div class="blog-item-holder">
                                    <div class="clear"></div>
                                    <div class="twelve columns">
                                        <div class="greennature-item greennature-blog-widget">
                                            <div class="greennature-ux greennature-blog-widget-ux">
                                                <article id="post-852"
                                                    class="post-852 post type-post status-publish format-standard has-post-thumbnail hentry category-fit-row tag-blog tag-life-style">
                                                    <div class="greennature-standard-style">
                                                        <div class="greennature-blog-thumbnail">
                                                            <a
                                                                href="https://demo.goodlayers.com/greennature/2013/12/11/donec-luctus-imperdiet/"><img
                                                                    src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_170752253-400x400.jpg"
                                                                    alt="" width="400"
                                                                    height="400" /></a>
                                                        </div>
                                                        <div class="greennature-blog-date-wrapper">
                                                            <div class="greennature-blog-day">11</div>
                                                            <div class="greennature-blog-month">Dec</div>
                                                        </div>
                                                        <header class="post-header">
                                                            <h3 class="greennature-blog-title"><a
                                                                    href="https://demo.goodlayers.com/greennature/2013/12/11/donec-luctus-imperdiet/">Eco
                                                                    Coin Rewards 1M Users</a></h3>
                                                            <div class="greennature-blog-info">
                                                                <div
                                                                    class="blog-info blog-comment greennature-skin-info">
                                                                    <i class="fa fa-comment-o"></i><a
                                                                        href="https://demo.goodlayers.com/greennature/2013/12/11/donec-luctus-imperdiet/#respond">2
                                                                        <span
                                                                            class="greennature-tail">Comments</span></a>
                                                                </div>
                                                                <div
                                                                    class="blog-info blog-author greennature-skin-info">
                                                                    <i class="fa fa-pencil"></i><a
                                                                        href="https://demo.goodlayers.com/greennature/author/superuser/"
                                                                        title="Posts by John Maxwell"
                                                                        rel="author">John Maxwell</a>
                                                                </div>
                                                                <div class="clear"></div>
                                                            </div>
                                                            <div class="clear"></div>
                                                        </header>
                                                        <div class="clear"></div>
                                                    </div>
                                                </article>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clear"></div>
                                    <div class="twelve columns">
                                        <div class="greennature-item greennature-blog-widget">
                                            <div class="greennature-ux greennature-blog-widget-ux">
                                                <article id="post-862"
                                                    class="post-862 post type-post status-publish format-standard has-post-thumbnail hentry category-blog category-fit-row tag-blog tag-link tag-news">
                                                    <div class="greennature-standard-style">
                                                        <div class="greennature-blog-thumbnail">
                                                            <a
                                                                href="https://demo.goodlayers.com/greennature/2013/12/09/magna-pars-studiorum/"><img
                                                                    src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_49617541-400x400.jpg"
                                                                    alt="" width="400"
                                                                    height="400" /></a>
                                                        </div>
                                                        <div class="greennature-blog-date-wrapper">
                                                            <div class="greennature-blog-day">09</div>
                                                            <div class="greennature-blog-month">Dec</div>
                                                        </div>
                                                        <header class="post-header">
                                                            <h3 class="greennature-blog-title"><a
                                                                    href="https://demo.goodlayers.com/greennature/2013/12/09/magna-pars-studiorum/">Top
                                                                    Eco Actions This Month</a></h3>
                                                            <div class="greennature-blog-info">
                                                                <div
                                                                    class="blog-info blog-comment greennature-skin-info">
                                                                    <i class="fa fa-comment-o"></i><a
                                                                        href="https://demo.goodlayers.com/greennature/2013/12/09/magna-pars-studiorum/#respond">2
                                                                        <span
                                                                            class="greennature-tail">Comments</span></a>
                                                                </div>
                                                                <div
                                                                    class="blog-info blog-author greennature-skin-info">
                                                                    <i class="fa fa-pencil"></i><a
                                                                        href="https://demo.goodlayers.com/greennature/author/superuser/"
                                                                        title="Posts by John Maxwell"
                                                                        rel="author">John Maxwell</a>
                                                                </div>
                                                                <div class="clear"></div>
                                                            </div>
                                                            <div class="clear"></div>
                                                        </header>
                                                        <div class="clear"></div>
                                                    </div>
                                                </article>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clear"></div>
                                    <div class="twelve columns">
                                        <div class="greennature-item greennature-blog-widget">
                                            <div class="greennature-ux greennature-blog-widget-ux">
                                                <article id="post-859"
                                                    class="post-859 post type-post status-publish format-standard has-post-thumbnail hentry category-blog category-fit-row tag-blog tag-life-stlyle">
                                                    <div class="greennature-standard-style">
                                                        <div class="greennature-blog-thumbnail">
                                                            <a
                                                                href="https://demo.goodlayers.com/greennature/2013/12/04/sedial-eiusmod-tempor/"><img
                                                                    src="https://demo.goodlayers.com/greennature/wp-content/uploads/2013/12/shutterstock_70658833-400x400.jpg"
                                                                    alt="" width="400"
                                                                    height="400" /></a>
                                                        </div>
                                                        <div class="greennature-blog-date-wrapper">
                                                            <div class="greennature-blog-day">04</div>
                                                            <div class="greennature-blog-month">Dec</div>
                                                        </div>
                                                        <header class="post-header">
                                                            <h3 class="greennature-blog-title"><a
                                                                    href="https://demo.goodlayers.com/greennature/2013/12/04/sedial-eiusmod-tempor/">How
                                                                    to Earn More {{ config('app.name') }}</a></h3>
                                                            <div class="greennature-blog-info">
                                                                <div
                                                                    class="blog-info blog-comment greennature-skin-info">
                                                                    <i class="fa fa-comment-o"></i><a
                                                                        href="https://demo.goodlayers.com/greennature/2013/12/04/sedial-eiusmod-tempor/#respond">0
                                                                        <span
                                                                            class="greennature-tail">Comment</span></a>
                                                                </div>
                                                                <div
                                                                    class="blog-info blog-author greennature-skin-info">
                                                                    <i class="fa fa-pencil"></i><a
                                                                        href="https://demo.goodlayers.com/greennature/author/superuser/"
                                                                        title="Posts by John Maxwell"
                                                                        rel="author">John Maxwell</a>
                                                                </div>
                                                                <div class="clear"></div>
                                                            </div>
                                                            <div class="clear"></div>
                                                        </header>
                                                        <div class="clear"></div>
                                                    </div>
                                                </article>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="four columns">
                            <div class="greennature-title-item" style="margin-bottom: 35px;">
                                <div
                                    class="greennature-item-title-wrapper greennature-item greennature-left-divider greennature-small">
                                    <div class="greennature-item-title-container container">
                                        <div class="greennature-item-title-head">
                                            <h3
                                                class="greennature-item-title greennature-skin-title greennature-skin-border">
                                                Current Campaign</h3>
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="greennature-video-item greennature-item"><iframe
                                    src="http://player.vimeo.com/video/101707505?title=0&byline=0&portrait=0"
                                    width="620" height="348"></iframe></div>
                            <div class="greennature-item greennature-content-item">
                                <p><strong><a style="font-size: 15px;" href="#">Learn more about Eco
                                            Coin</a></strong></p>
                            </div>
                        </div>
                        <div class="four columns">
                            <div class="greennature-testimonial-item-wrapper">
                                <div
                                    class="greennature-item-title-wrapper greennature-item greennature-nav-container greennature-left-divider greennature-small">
                                    <div class="greennature-item-title-container container">
                                        <div class="greennature-item-title-head">
                                            <h3
                                                class="greennnature-item-title greennature-skin-title greennature-skin-border">
                                                Testimonials</h3><span class="greennature-nav-title"><i
                                                    class="icon-angle-left greennature-flex-prev"></i><i
                                                    class="icon-angle-right greennature-flex-next"></i></span>
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="greennature-item greennature-testimonial-item carousel greennature-left plain-style">
                                    <div class="greennature-ux greennature-testimonial-ux">
                                        <div class="flexslider" data-type="carousel"
                                            data-nav-container="greennature-testimonial-item" data-columns="1">
                                            <ul class="slides">
                                                <li class="testimonial-item">
                                                    <div class="testimonial-content-wrapper">
                                                        <div class="testimonial-content greennature-skin-content">
                                                            <p>{{ config('app.name') }} made it so easy to earn crypto by
                                                                planting trees in my community. It’s rewarding
                                                                to help the planet and get paid!</p>
                                                        </div>
                                                        <div class="testimonial-info">
                                                            <div
                                                                class="testimonial-author-image greennature-skin-border">
                                                                <img src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/testimonial-3-150x150.jpg"
                                                                    alt="" width="150" height="150" />
                                                            </div>
                                                            <span
                                                                class="testimonial-author greennature-skin-link-color">Sarah
                                                                Kof<span>, </span></span><span
                                                                class="testimonial-position greennature-skin-info">Eco
                                                                Warrior</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="testimonial-item">
                                                    <div class="testimonial-content-wrapper">
                                                        <div class="testimonial-content greennature-skin-content">
                                                            <p>Uploading my beach cleanup videos was simple, and
                                                                I earned {{ config('app.name') }} quickly. This platform is a
                                                                game-changer!</p>
                                                        </div>
                                                        <div class="testimonial-info">
                                                            <div
                                                                class="testimonial-author-image greennature-skin-border">
                                                                <img src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/testimonial-1-150x150.jpg"
                                                                    alt="" width="150" height="150" />
                                                            </div>
                                                            <span
                                                                class="testimonial-author greennature-skin-link-color">Jane
                                                                Doe<span>, </span></span><span
                                                                class="testimonial-position greennature-skin-info">Eco
                                                                Warrior</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="testimonial-item">
                                                    <div class="testimonial-content-wrapper">
                                                        <div class="testimonial-content greennature-skin-content">
                                                            <p>I love how {{ config('app.name') }} rewards my recycling efforts
                                                                with crypto. It motivates me to live greener
                                                                every day.</p>
                                                        </div>
                                                        <div class="testimonial-info">
                                                            <div
                                                                class="testimonial-author-image greennature-skin-border">
                                                                <img src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/testimonial-2-150x150.jpg"
                                                                    alt="" width="150" height="150" />
                                                            </div>
                                                            <span
                                                                class="testimonial-author greennature-skin-link-color">John
                                                                Smith<span>, </span></span><span
                                                                class="testimonial-position greennature-skin-info">Eco
                                                                Warrior</span>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="clear"></div>
            </section>