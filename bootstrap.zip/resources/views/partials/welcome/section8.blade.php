<section id="content-section-8">
    <div class="greennature-color-wrapper gdlr-show-all greennature-skin-dark-skin"
        style="background-color: #1d1d1d; padding-bottom: 60;">
        <div class="container">
            <div class="twelve columns">
                <div class="greennature-stunning-item-ux greennature-ux">
                    <div
                        class="greennature-item greennature-stunning-item greennature-button-on greennature-stunning-left">
                        <h2 class="stunning-item-title">How {{ config('app.name') }} Works</h2>
                        <div class="stunning-item-caption greennature-skin-content">
                            <p>Log in, upload media of your eco-friendly activities, and earn Eco
                                Coin after our team reviews your efforts. Start making a difference
                                today!</p>
                        </div><a class="stunning-item-button greennature-button large" href="/login"
                            target="_blank">Join Now</a>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <div class="clear"></div>
</section>
