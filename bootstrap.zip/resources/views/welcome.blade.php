@extends('layouts.master')
@section('content')

    @include('partials.welcome.section1')

    @include('partials.welcome.section2')

    @include('partials.welcome.section3')

    @include('partials.welcome.section4')

    @include('partials.welcome.section5')

    @include('partials.welcome.section6')

    @include('partials.welcome.section7')

    @include('partials.welcome.section8')
    
    @include('partials.welcome.section9')
    
@endsection
