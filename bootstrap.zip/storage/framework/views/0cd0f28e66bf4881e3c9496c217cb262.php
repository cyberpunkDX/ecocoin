
<?php /**PATH C:\Users\DX\workspace\laravel\ecocoin\resources\views/partials/live_chat.blade.php ENDPATH**/ ?>