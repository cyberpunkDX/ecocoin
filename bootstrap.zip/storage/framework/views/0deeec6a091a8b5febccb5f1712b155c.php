<section id="content-section-9">
                <div class="greennature-parallax-wrapper greennature-background-image gdlr-show-all greennature-skin-dark-skin"
                    id="greennature-parallax-wrapper-3" data-bgspeed="0.15"
                    style="background-image: url('https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/service-bg-2.jpg'); padding-top: 135px; padding-bottom: 80px;">
                    <div class="container">
                        <div class="three columns">
                            <div class="greennature-skill-item-wrapper greennature-skin-content greennature-item greennature-style-2"
                                style="margin-bottom: 70px;"><img
                                    src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/icon-4.png"
                                    alt="" width="80" height="80" />
                                <div class="greennature-skill-item-title" style="color: #5dc269;">500,000</div>
                                <div class="greennature-skill-item-caption" style="color: #ffffff;">Eco Actions
                                    Shared</div>
                            </div>
                        </div>
                        <div class="three columns">
                            <div class="greennature-skill-item-wrapper greennature-skin-content greennature-item greennature-style-2"
                                style="margin-bottom: 70px;"><img
                                    src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/icon-5.png"
                                    alt="" width="80" height="80" />
                                <div class="greennature-skill-item-title" style="color: #5dc269;">1M</div>
                                <div class="greennature-skill-item-caption" style="color: #ffffff;"><?php echo e(config('app.name')); ?>s
                                    Rewarded</div>
                            </div>
                        </div>
                        <div class="three columns">
                            <div class="greennature-skill-item-wrapper greennature-skin-content greennature-item greennature-style-2"
                                style="margin-bottom: 70px;"><img
                                    src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/icon-1.png"
                                    alt="" width="80" height="80" />
                                <div class="greennature-skill-item-title" style="color: #5dc269;">250,000</div>
                                <div class="greennature-skill-item-caption" style="color: #ffffff;">Active Users
                                </div>
                            </div>
                        </div>
                        <div class="three columns">
                            <div class="greennature-skill-item-wrapper greennature-skin-content greennature-item greennature-style-2"
                                style="margin-bottom: 70px;"><img
                                    src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/icon-2.png"
                                    alt="" width="80" height="80" />
                                <div class="greennature-skill-item-title" style="color: #5dc269;">100K</div>
                                <div class="greennature-skill-item-caption" style="color: #ffffff;">Trees
                                    Planted</div>
                            </div>
                        </div>
                        <div class="clear"></div>
                        <div class="clear"></div>
                        <div class="greennature-item greennature-divider-item" style="margin-bottom: 60px;">
                            <div class="greennature-divider thick"></div>
                        </div>
                        <div class="clear"></div>
                        <div class="greennature-stunning-item-ux greennature-ux">
                            <div class="greennature-item greennature-stunning-item greennature-stunning-center">
                                <h2 class="stunning-item-title">Act Green, Earn Crypto!</h2>
                                <div class="stunning-item-caption greennature-skin-content">
                                    <p>Join <?php echo e(config('app.name')); ?>, share your eco-friendly actions, and earn rewards for
                                        building a sustainable future.</p>
                                </div><a class="stunning-item-button greennature-button large greennature-lb-payment"
                                    href="#" style="background-color: #ecb338; color: #ffffff;">Sign Up
                                    Now!</a><a class="stunning-item-button greennature-button large"
                                    href="https://demo.goodlayers.com/greennature/act-now/">Start Sharing!</a>
                            </div>
                        </div>
                        <div class="clear"></div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="clear"></div>
            </section><?php /**PATH C:\Users\DX\workspace\laravel\ecocoin\resources\views/partials/welcome/section9.blade.php ENDPATH**/ ?>