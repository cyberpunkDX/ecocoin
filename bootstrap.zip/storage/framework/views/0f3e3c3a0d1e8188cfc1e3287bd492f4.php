<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo e(@$title); ?></h1>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4><?php echo e($title); ?></h4>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <dl class="row mb-0">
                                    <dt class="col-12 col-sm-4 fw-bold">Name</dt>
                                    <dd class="col-12 col-sm-8"><?php echo e($pricing->name); ?></dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Minimum</dt>
                                    <dd class="col-12 col-sm-8"><?php echo e(formatAmount($pricing->minimum)); ?></dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Maximum</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e($pricing->maximum ? formatAmount($pricing->maximum) : 'Not specified'); ?>

                                    </dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Features</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e($pricing->features); ?>

                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer text-right">
                        <a href="<?php echo e(route('admin.pricing.edit', $pricing->uuid)); ?>" class='btn btn-primary'><i
                                class='fa fa-edit'></i> Edit</a>
                        <a href="<?php echo e(route('admin.pricing.index')); ?>" class='btn btn-secondary'><i
                                class='fa fa-arrow-left'></i>
                            Back</a>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/admin/pricing/show.blade.php ENDPATH**/ ?>