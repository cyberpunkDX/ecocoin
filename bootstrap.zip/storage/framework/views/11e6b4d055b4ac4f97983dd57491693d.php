<?php $__env->startSection('content'); ?>
    <div class="login-card mx-2">
        <div class="card-header align-items-center d-flex justify-content-center">
            <img src="<?php echo e(env('APP_LOGO_DARK')); ?>" class="w-50" alt="">
        </div>

        <div class="card-body p-4">
            <?php if(session('status')): ?>
                <p class="text-success"> <?php echo e(session('status')); ?></p>
            <?php endif; ?>
            <form action="/login" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="email" class="form-label">Username or Email</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" name="email" class="form-control" required value="<?php echo e(old('email')); ?>" id="email"
                            type="email" placeholder="Email Address">
                    </div>
                    <?php if($errors->has('email')): ?>
                        <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>" id="password"
                            type="password" placeholder="Password ">

                    </div>
                    <?php if($errors->has('password')): ?>
                        <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-login text-white"><i class="fas fa-sign-in-alt"></i>
                        Login</button>
                </div>
                <div class="text-center">
                    <a href="#" class="forgot-password">Forgot Password?</a>
                </div>
            </form>
            <div class="text-center mt-3">
                <p>Don't have an account? <a href="/register" class="eco-green">Sign Up</a></p>
            </div>
        </div>
        
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\ecocoin\resources\views/auth/login.blade.php ENDPATH**/ ?>