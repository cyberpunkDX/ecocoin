<!-- section content begin -->
<div class="uk-section in-wave-4">
    <div class="uk-container">
        <div class="uk-grid uk-flex uk-flex-center">
            <div class="uk-width-1-1 uk-text-center">
                <h1 class="uk-margin-medium-bottom"><span class="in-highlight">Complete</span> package for every investor
                </h1>
            </div>
            <div class="uk-width-3-4@m">
                <div class="uk-grid-collapse uk-child-width-1-2@m in-wave-pricing" data-uk-grid>
                    <div>
                        <div class="uk-card uk-card-default uk-card-body uk-box-shadow-medium">
                            <p class="uk-text-small uk-text-uppercase">Minimum deposit<span
                                    class="uk-label in-label-small uk-margin-small-left">USD 150</span></p>
                            <h2 class="uk-margin-top uk-margin-remove-bottom">Starter Plan</h2>
                            <p class="uk-text-lead uk-text-muted uk-margin-remove-top">Begin your affiliate investment
                                journey with ease</p>
                            <hr>
                            <ul class="uk-list in-list-check">
                                <li>Access to beginner-friendly campaigns</li>
                                <li>Expert campaign management</li>
                                <li>Real-time profit tracking</li>
                                <li>Flexible withdrawals</li>
                                <li>Basic risk management tools</li>
                                <li>24/7 customer support</li>
                                <li>Low entry deposit</li>
                            </ul>
                            <a href="#"
                                class="uk-button uk-button-default uk-border-rounded uk-align-center">Start Investing<i
                                    class="fas fa-chevron-circle-right fa-xs uk-margin-small-left"></i></a>
                        </div>
                    </div>
                    <div>
                        <div class="uk-card uk-card-default uk-card-body uk-box-shadow-large">
                            <p class="uk-text-small uk-text-uppercase">Minimum deposit<span
                                    class="uk-label in-label-small uk-margin-small-left">USD 200</span></p>
                            <h2 class="uk-margin-top uk-margin-remove-bottom">Premium Plan</h2>
                            <p class="uk-text-lead uk-text-muted uk-margin-remove-top">Unlock higher returns with
                                advanced features</p>
                            <hr>
                            <ul class="uk-list in-list-check">
                                <li>Priority access to top campaigns</li>
                                <li>Enhanced profit potential</li>
                                <li>Detailed performance analytics</li>
                                <li>Instant withdrawal processing</li>
                                <li>Advanced risk management</li>
                                <li>Dedicated expert support</li>
                                <li>Exclusive investment insights</li>
                            </ul>
                            <a href="#"
                                class="uk-button uk-button-primary uk-border-rounded uk-align-center">Start Investing<i
                                    class="fas fa-chevron-circle-right fa-xs uk-margin-small-left"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="uk-width-1-1">
                <div class="uk-grid-medium uk-child-width-1-2@s uk-child-width-1-5@m uk-text-center uk-margin-large-top"
                    data-uk-grid>
                    <div>
                        <img src="img/in-lazy.gif" data-src="img/in-wave-award.svg" alt="wave-award" width="71"
                            height="58" data-uk-img>
                        <h6 class="uk-margin-small-top uk-margin-remove-bottom">Best Affiliate Platform</h6>
                        <p class="uk-text-small uk-margin-remove-top">Affiliate Summit 2023</p>
                    </div>
                    <div>
                        <img src="img/in-lazy.gif" data-src="img/in-wave-award.svg" alt="wave-award" width="71"
                            height="58" data-uk-img>
                        <h6 class="uk-margin-small-top uk-margin-remove-bottom">Top Investment Tool</h6>
                        <p class="uk-text-small uk-margin-remove-top">Marketing Expo 2023</p>
                    </div>
                    <div>
                        <img src="img/in-lazy.gif" data-src="img/in-wave-award.svg" alt="wave-award" width="71"
                            height="58" data-uk-img>
                        <h6 class="uk-margin-small-top uk-margin-remove-bottom">Best ROI Platform</h6>
                        <p class="uk-text-small uk-margin-remove-top">Global Invest 2023</p>
                    </div>
                    <div>
                        <img src="img/in-lazy.gif" data-src="img/in-wave-award.svg" alt="wave-award" width="71"
                            height="58" data-uk-img>
                        <h6 class="uk-margin-small-top uk-margin-remove-bottom">Top User Experience</h6>
                        <p class="uk-text-small uk-margin-remove-top">Tech Awards 2023</p>
                    </div>
                    <div class="uk-visible@m">
                        <img src="img/in-lazy.gif" data-src="img/in-wave-award.svg" alt="wave-award" width="71"
                            height="58" data-uk-img>
                        <h6 class="uk-margin-small-top uk-margin-remove-bottom">Best Passive Income</h6>
                        <p class="uk-text-small uk-margin-remove-top">Finance Expo 2023</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- section content end -->
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/partials/welcome/section4.blade.php ENDPATH**/ ?>