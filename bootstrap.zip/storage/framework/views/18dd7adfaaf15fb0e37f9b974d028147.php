<!doctype html>
<html lang="en">

    <head>
        <!-- meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="<?php echo e(env('APP_DESCRIPTION')); ?>">
        <meta name="author" content="<?php echo e(env('APP_NAME')); ?>">
        <meta name="theme-color" content="#FCB42D">
        <!-- preload assets -->
        <link rel="preload" href="<?php echo e(asset('fonts/fa-brands-400.woff2')); ?>" as="font" type="font/woff2"
            crossorigin>
        <link rel="preload" href="<?php echo e(asset('fonts/fa-solid-900.woff2')); ?>" as="font" type="font/woff2"
            crossorigin>
        <link rel="preload" href="<?php echo e(asset('fonts/rubik-v9-latin-regular.woff2')); ?>" as="font" type="font/woff2"
            crossorigin>
        <link rel="preload" href="<?php echo e(asset('fonts/rubik-v9-latin-500.woff2')); ?>" as="font" type="font/woff2"
            crossorigin>
        <link rel="preload" href="<?php echo e(asset('fonts/rubik-v9-latin-300.woff2')); ?>" as="font" type="font/woff2"
            crossorigin>
        <link rel="preload" href="<?php echo e(asset('css/style.css')); ?>" as="style">
        <link rel="preload" href="<?php echo e(asset('js/vendors/uikit.min.js')); ?>" as="script">
        <link rel="preload" href="<?php echo e(asset('js/utilities.min.js')); ?>" as="script">
        <link rel="preload" href="<?php echo e(asset('js/config-theme.js')); ?>" as="script">
        <!-- stylesheet -->
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <!-- uikit -->
        <script src="<?php echo e(asset('js/vendors/uikit.min.js')); ?>"></script>
        <!-- favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset(env('APP_FAVICON'))); ?>" type="image/x-icon">
        <!-- touch icon -->
        <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset(env('APP_FAVICON'))); ?>">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
        </script>
        <script src="<?php echo e(asset('assets/js/sweet_alert.js')); ?>"></script>
        <title><?php echo e($title); ?> | <?php echo e(env('APP_NAME')); ?></title>
    </head>

    <body>
        <?php echo $__env->make('layouts.partials.loader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main>
            <?php echo $__env->make('partials.sweet_alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('layouts.partials.to_top', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- javascript -->
        <script src="<?php echo e(asset('js/utilities.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/config-theme.js')); ?>"></script>

        <?php echo $__env->make('partials.live_chat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </body>

</html>
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/layouts/master.blade.php ENDPATH**/ ?>