<!-- section content begin -->
<div class="uk-section uk-section-primary uk-padding-remove-vertical in-wave-1">
    <div class="uk-container">
        <div class="uk-grid uk-grid-divider uk-child-width-1-2@s uk-child-width-1-4@m in-margin-top@s in-margin-bottom@s"
            data-uk-grid>
            <div>
                <div class="uk-grid uk-grid-small uk-flex uk-flex-middle">
                    <div class="uk-width-auto">
                        <img src="img/in-lazy.gif" data-src="img/in-wave-icon-1.svg" alt="wave-icon" width="48"
                            height="48" data-uk-img>
                    </div>
                    <div class="uk-width-expand">
                        <p>Free<br>campaign insights</p>
                    </div>
                </div>
            </div>
            <div>
                <div class="uk-grid uk-grid-small uk-flex uk-flex-middle">
                    <div class="uk-width-auto">
                        <img src="img/in-lazy.gif" data-src="img/in-wave-icon-2.svg" alt="wave-icon" width="48"
                            height="48" data-uk-img>
                    </div>
                    <div class="uk-width-expand">
                        <p>Fast profit<br>tracking</p>
                    </div>
                </div>
            </div>
            <div>
                <div class="uk-grid uk-grid-small uk-flex uk-flex-middle">
                    <div class="uk-width-auto">
                        <img src="img/in-lazy.gif" data-src="img/in-wave-icon-3.svg" alt="wave-icon" width="48"
                            height="48" data-uk-img>
                    </div>
                    <div class="uk-width-expand">
                        <p>Low entry<br>deposit of $50</p>
                    </div>
                </div>
            </div>
            <div>
                <div class="uk-grid uk-grid-small uk-flex uk-flex-middle">
                    <div class="uk-width-auto">
                        <img src="img/in-lazy.gif" data-src="img/in-wave-icon-4.svg" alt="wave-icon" width="48"
                            height="48" data-uk-img>
                    </div>
                    <div class="uk-width-expand">
                        <p>Over 500<br>expert campaigns</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- section content end -->
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/partials/welcome/section1.blade.php ENDPATH**/ ?>