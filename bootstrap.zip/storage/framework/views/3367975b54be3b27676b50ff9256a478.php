<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo e(@$title); ?></h1>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4><?php echo e($title); ?></h4>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <img width="200" src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                    class="img-thumbnail">
                            </div>
                            <div class="col-12">
                                <dl class="row mb-0">
                                    <dt class="col-12 col-sm-4 fw-bold">Name</dt>
                                    <dd class="col-12 col-sm-8"><?php echo e($product->name); ?></dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Description</dt>
                                    <dd class="col-12 col-sm-8"><?php echo $product->description; ?></dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Price</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e(formatAmount($product->price)); ?>

                                    </dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Status</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php if($product->status == 1): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Inactive</span>
                                        <?php endif; ?>
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer text-right">
                        <a href="<?php echo e(route('admin.product.edit', $product->uuid)); ?>" class='btn btn-primary'><i
                                class='fa fa-edit'></i> Edit</a>
                        <a href="<?php echo e(route('admin.product.index')); ?>" class='btn btn-secondary'><i
                                class='fa fa-arrow-left'></i>
                            Back</a>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/admin/product/show.blade.php ENDPATH**/ ?>