<section id="content-section-7">
    <div class="greennature-parallax-wrapper greennature-background-image gdlr-show-all greennature-skin-newsletter"
        id="greennature-parallax-wrapper-2" data-bgspeed="0"
        style="background-image: url('https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/newsletter-bg.jpg'); padding-top: 145px; padding-bottom: 60px;">
        <div class="container">
            <div class="greennature-title-item" style="margin-bottom: 45px;">
                <div class="greennature-item-title-wrapper greennature-item greennature-center greennature-large">
                    <div class="greennature-item-title-container container">
                        <div class="greennature-item-title-head">
                            <h3 class="greennature-item-title greennature-skin-title greennature-skin-border">
                                Stay Updated</h3>
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
            <div class="greennature-subscribe-item greennature-item">
                <div class="greennature-newsletter-subscribe">
                    <div class="newsletter newsletter-subscription">
                        <form method="post" action="https://demo.goodlayers.com/greennature/?na=s"
                            onsubmit="return newsletter_check(this)">
                            <input class="newsletter-email" type="email" name="ne" size="30" required
                                placeholder="Enter your email for <?php echo e(config('app.name')); ?> updates" />
                            <input class="newsletter-submit greennature-button" type="submit" value="Subscribe!" />
                            <input type="hidden" name="nr" value="widget" />
                        </form>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
            <div class="clear"></div>
        </div>
    </div>
    <div class="clear"></div>
</section>
<?php /**PATH C:\Users\DX\workspace\laravel\ecocoin\resources\views/partials/welcome/section7.blade.php ENDPATH**/ ?>