<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['transactions']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['transactions']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex flex-wrap align-items-center gap-2">
                <h4 class="header-title me-auto">Transactions <span
                        class="text-muted fw-normal fs-14">(<?php echo e($transactions->count()); ?>

                        Transactions)</span></h4>

                <div class="search-bar">
                    <input type="text" class="form-control form-control-sm search" placeholder="Search Here...">
                </div>

                <div class="w-auto">
                    <select class="form-select form-select-sm">
                        <option selected="">All</option>
                        <option value="0">Paid</option>
                        <option value="1">Cancelled</option>
                        <option value="2">Failed</option>
                        <option value="2">Onhold</option>
                    </select>
                </div>

                <a href="javascript:void(0);" class="btn btn-sm btn-soft-primary">Export <i
                        class="ti ti-file-export ms-1"></i></a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive table-card">
                    <table class="table table-borderless table-hover table-custom table-nowrap align-middle mb-0">
                        <thead class="bg-light bg-opacity-50 thead-sm">
                            <tr class="text-uppercase fs-12">
                                <th scope="col" class="text-muted">ID</th>
                                <th scope="col" class="text-muted">Type</th>
                                <th scope="col" class="text-muted">Description</th>
                                <th scope="col" class="text-muted">Amount</th>
                                <th scope="col" class="text-muted">Timestamp</th>
                                <th scope="col" class="text-muted">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($transaction->uuid); ?></td>
                                    <td><?php echo e($transaction->type); ?></td>
                                    <td><?php echo e(limitText($transaction->description)); ?></td>
                                    <td><?php echo e(formatAmount($transaction->amount)); ?></td>
                                    <td><?php echo e($transaction->created_at->format('F j, Y, g:i A')); ?></td>
                                    <td><span class="badge badge-lg 
                                        <?php if($transaction->status === 'successful'): ?> bg-success 
                                        <?php elseif($transaction->status === 'pending'): ?> bg-warning 
                                        <?php else: ?> bg-danger <?php endif; ?>">
                                        <?php echo e(ucfirst($transaction->status ?? 'Pending')); ?>

                                    </span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="w-100 bg-tertiary h-50">
                                    <td>
                                        <p>No transactions available on your account</p>
                                    </td>
                                </div>
                            <?php endif; ?>

                        </tbody>
                    </table><!-- end table -->
                </div><!-- end table responsive -->
            </div> <!-- End Card-body -->
            <div class="card-footer border-top border-light">

            </div>
        </div> <!-- end card-->
    </div> <!-- end col-->
</div>
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/components/transactions.blade.php ENDPATH**/ ?>