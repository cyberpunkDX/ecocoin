<?php if(session()->has('success')): ?>
    <script>
        swal("Success...", "<?php echo e(session()->get('success')); ?>", "success");
    </script>
<?php elseif(session()->has('error')): ?>
    <script>
        swal("Error...", "<?php echo e(session()->get('error')); ?>", "error");
    </script>
<?php endif; ?>
<?php /**PATH C:\Users\DX\workspace\laravel\ecocoin\resources\views/partials/sweet_alert.blade.php ENDPATH**/ ?>