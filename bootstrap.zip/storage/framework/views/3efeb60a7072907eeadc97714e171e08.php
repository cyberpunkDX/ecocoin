
<?php $__env->startSection('content'); ?>

    <div class="content-wrapper bg-navy" style="min-height: 697px;">
        <div class="container-full">
            <!-- Content Header (Page header) -->

            <!-- Main content -->
            <section class="content">
                <!-- Basic Card Example -->
                <div class="row">
                    <div class="col-sm-12 col-md-12">
                        <div class="mb-4 border-bottom-success">
                            <div class="card-header py-3 d-flex justify-content-between">
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-md-7">
                                    <?php echo $__env->make('partials.validation_message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    <?php if($user->card): ?>
                                        <?php if($user->card->cvv != null): ?>
                                            <div class="card-container">
                                                <div class="virtual-card">
                                                    <div class="card-header">
                                                        <div class="card-info">
                                                            <h5>Balance</h5>
                                                            <h3><?php echo e($user->card ? currency($user->currency) . formatAmount($user->card->balance) : '00'); ?>

                                                            </h3>
                                                        </div>
                                                        <div class="chip">
                                                            <img class="img-fluid" src="<?php echo e(asset('card-terminal.png')); ?>"
                                                                alt="" srcset="">
                                                        </div>
                                                    </div>
                                                    <div class="card-number">
                                                        <?php echo e($user->card ? $user->card->number : '**** *** **** ****'); ?>

                                                    </div>
                                                    <div class="card-footer">
                                                        <div class="card-details">
                                                            <p>CARD HOLDER</p>
                                                            <span><?php echo e($user->first_name . ' ' . $user->last_name); ?></span>
                                                        </div>
                                                        <div class="card-details">
                                                            <p>VALID THRU</p>
                                                            <span><?php echo e($user->card ? $user->card->date : '00/00'); ?></span>
                                                        </div>
                                                        <img src="<?php echo e(asset('master-card.svg')); ?>" alt="Mastercard Logo"
                                                            class="card-logo">
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <div class="card">
                                        <div class="card-body">
                                            <form action="<?php echo e(route('user.card.store')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group mb-3">
                                                    <label for="name">Name</label>
                                                    <input type="text" class="form-control" id="name" name="name"
                                                        value="<?php echo e(old('name', $user->name)); ?>"
                                                        readonly>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group mb-3">
                                                            <label for="phone">Phone Number</label>
                                                            <input type="text" class="form-control" id="phone" name="phone"
                                                                value="<?php echo e(old('phone', $user->phone)); ?>" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group mb-3">
                                                            <label for="email">Email</label>
                                                            <input type="email" class="form-control" id="email" name="email"
                                                                value="<?php echo e(old('email', $user->email)); ?>" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="type">Type of Card</label>
                                                    <select class="form-control" id="type" name="type" required>
                                                        <option value="">Select</option>
                                                        <?php $__currentLoopData = $cardTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cardType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($cardType->value); ?>"><?php echo e($cardType->name); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group mb-3">
                                                    <label for="residential_address">Residential Address</label>
                                                    <input type="text" class="form-control" id="residential_address"
                                                        name="residential_address"
                                                        value="<?php echo e(old('residential_address', $user->address)); ?>" required>
                                                </div>
                                               
                                            
                                                <button type="submit" class="btn btn-primary mt-4">Submit Request</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-5">
                                    <div class="card">
                                        <div class="card-header">Card Request Details</div>
                                        <div class="card-body">
                                            <?php $__empty_1 = true; $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <p>Submitted Application Date: <?php echo e($card->date); ?></p>
                                                <p>Application Status: <?php echo e($card->status == 0 ? 'Pending' : 'Approved'); ?>

                                                </p>
                                                <p>Card Type:

                                                    <?php $__currentLoopData = $cardTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cardType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($card->type == $cardType->value): ?>
                                                            <?php echo e($cardType->name); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </p>
                                                <hr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php echo $__env->make('dashboard.user.layouts.partials.card-details', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- /.content -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.user.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/card/index.blade.php ENDPATH**/ ?>