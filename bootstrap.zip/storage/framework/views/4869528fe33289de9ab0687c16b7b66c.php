<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12 col-md-12">
        <h1 class="text-center mb-4"><?php echo e($title); ?></h1>
        <p class="text-center">Select a wallet to deposit into your account.</p>
    </div>
    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 mb-4 rounded mb-2 shadow">
            <a href="<?php echo e(route('user.deposit.checkout', $wallet->uuid)); ?>">
                <div class="card h-100">
                    <div class="row">
                        <div class="col-2 mt-3">
                            <div style="width: 65px; height:65px;" class="my-auto">
                                <img src="<?php echo e(asset('uploads/wallet/logos/' . $wallet->logo)); ?>" class="img-fluid"
                                    alt="">
                            </div>
                        </div>
                        <div class="col-10">
                            <div class="card-body rounded">
                                <h5 class="card-title"><?php echo e($wallet->name); ?></h5>
                                <p class="text-secondary"><?php echo e($wallet->network); ?></p>
                                <p class="text-dark"><?php echo e($wallet->address); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/deposit/index.blade.php ENDPATH**/ ?>