<section id="content-section-1">
    <div class="greennature-full-size-wrapper gdlr-show-all no-skin"
        style="padding-bottom: 0px; background-color: #ffffff;">
        <div class="greennature-master-slider-item greennature-slider-item greennature-item" style="margin-bottom: 0px;">
            <!-- MasterSlider -->
            <div id="P_MS68558d0849323" class="master-slider-parent ms-parent-id-1">
                <!-- MasterSlider Main -->
                <div id="MS68558d0849323" class="master-slider ms-skin-default">
                    <div class="ms-slide" data-delay="7" data-fill-mode="fill">
                        <img src="https://demo.goodlayers.com/greennature/wp-content/plugins/masterslider/public/assets/css/blank.gif"
                            alt="" title=""
                            data-src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/slider-1.jpg" />
                        <a href="#" target="_self"
                            class="ms-layer ms-btn ms-btn-round ms-btn-n msp-preset-btn-159"
                            data-effect="t(true,n,n,-500,n,n,n,n,n,n,n,n,n,n,n)" data-duration="400" data-delay="987"
                            data-ease="easeOutQuint" data-type="button" data-offset-x="1" data-offset-y="208"
                            data-origin="ml">Get Started</a>
                        <div class="ms-layer msp-cn-1-3" style=""
                            data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="437" data-delay="625"
                            data-ease="easeOutQuint" data-offset-x="0" data-offset-y="105" data-origin="ml"><?php echo e(config('app.name')); ?>

                        </div>
                        <div class="ms-layer msp-cn-1-2" style=""
                            data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="425" data-delay="325"
                            data-ease="easeOutQuint" data-offset-x="0" data-offset-y="-5" data-origin="ml">Earn Crypto
                        </div>
                        <div class="ms-layer msp-cn-1-1" style=""
                            data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="350"
                            data-ease="easeOutQuint" data-offset-x="0" data-offset-y="-100" data-origin="ml">Go Green
                        </div>
                    </div>
                    <div class="ms-slide" data-delay="7" data-fill-mode="fill">
                        <img src="https://demo.goodlayers.com/greennature/wp-content/plugins/masterslider/public/assets/css/blank.gif"
                            alt="" title=""
                            data-src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/slider-2.jpg" />
                        <a href="#" target="_self"
                            class="ms-layer ms-btn ms-btn-round ms-btn-n msp-preset-btn-159"
                            data-effect="t(true,n,n,-500,n,n,n,n,n,n,n,n,n,n,n)" data-duration="400" data-delay="987"
                            data-ease="easeOutQuint" data-type="button" data-offset-x="1" data-offset-y="227"
                            data-origin="ml">Get Started</a>
                        <div class="ms-layer msp-cn-1-9" style=""
                            data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="437" data-delay="625"
                            data-ease="easeOutQuint" data-offset-x="0" data-offset-y="139" data-origin="ml">Share Your
                        </div>
                        <div class="ms-layer msp-cn-1-7" style=""
                            data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="437" data-delay="625"
                            data-ease="easeOutQuint" data-offset-x="383" data-offset-y="139" data-origin="ml">Eco
                            Actions</div>
                        <div class="ms-layer msp-cn-1-5" style=""
                            data-effect="t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n)" data-duration="350"
                            data-ease="easeOutQuint" data-offset-x="0" data-offset-y="52" data-origin="ml">
                            Earn Rewards</div>
                    </div>
                    <div class="ms-slide" data-delay="7" data-fill-mode="fill">
                        <img src="https://demo.goodlayers.com/greennature/wp-content/plugins/masterslider/public/assets/css/blank.gif"
                            alt="" title=""
                            data-src="https://demo.goodlayers.com/greennature/wp-content/uploads/2015/10/slider-3.jpg" />
                        <div class="ms-layer msp-cn-1-10" style=""
                            data-effect="t(true,n,n,-500,n,n,n,n,n,n,n,n,n,n,n)" data-duration="425" data-delay="425"
                            data-ease="easeOutQuint" data-offset-x="0" data-offset-y="82" data-origin="mc">Green
                            Today</div>
                        <div class="ms-layer msp-cn-1-13" style=""
                            data-effect="t(true,n,n,500,n,n,n,n,n,n,n,n,n,n,n)" data-duration="437"
                            data-ease="easeOutQuint" data-offset-x="0" data-offset-y="-15" data-origin="mc">Rewarded
                            Tomorrow</div>
                    </div>
                </div>
                <!-- END MasterSlider Main -->
            </div>
            <!-- END MasterSlider -->
            <script data-cfasync="false"
                src="https://demo.goodlayers.com/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
            <script>
                (window.MSReady = window.MSReady || []).push(function($) {
                    "use strict";
                    var masterslider_9323 = new MasterSlider();
                    masterslider_9323.control('arrows', {
                        autohide: true,
                        overVideo: true
                    });
                    masterslider_9323.control('bullets', {
                        autohide: false,
                        overVideo: true,
                        dir: 'h',
                        align: 'bottom',
                        space: 6,
                        margin: 25
                    });
                    masterslider_9323.setup("MS68558d0849323", {
                        width: 1140,
                        height: 800,
                        minHeight: 0,
                        space: 0,
                        start: 1,
                        grabCursor: false,
                        swipe: true,
                        mouse: false,
                        keyboard: true,
                        layout: "fullwidth",
                        wheel: false,
                        autoplay: false,
                        instantStartLayers: false,
                        mobileBGVideo: false,
                        loop: true,
                        shuffle: false,
                        preload: 0,
                        heightLimit: true,
                        autoHeight: false,
                        smoothHeight: true,
                        endPause: false,
                        overPause: true,
                        fillMode: "fill",
                        centerControls: true,
                        startOnAppear: false,
                        layersMode: "center",
                        autofillTarget: "",
                        hideLayers: false,
                        fullscreenMargin: 0,
                        speed: 20,
                        dir: "h",
                        responsive: true,
                        tabletWidth: 768,
                        tabletHeight: null,
                        phoneWidth: 480,
                        phoneHeight: null,
                        sizingReference: window,
                        parallaxMode: 'swipe',
                        view: "basic"
                    });
                    window.masterslider_instances = window.masterslider_instances || [];
                    window.masterslider_instances.push(masterslider_9323);
                });
            </script>
        </div>
        <div class="clear"></div>
        <div class="clear"></div>
    </div>
    <div class="clear"></div>
</section>
<?php /**PATH C:\Users\DX\workspace\laravel\ecocoin\resources\views/partials/welcome/section1.blade.php ENDPATH**/ ?>