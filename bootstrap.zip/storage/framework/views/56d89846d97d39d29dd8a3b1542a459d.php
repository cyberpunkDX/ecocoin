  <!-- Footer Start -->
  <footer class="footer">
      <div class="page-container">
          <div class="row">
              <div class="col-md-6 text-center text-md-start">
                  <script>
                      document.write(new Date().getFullYear())
                  </script> © <?php echo e(env('APP_NAME')); ?> All rights reserved.
              </div>
              <div class="col-md-6">
                  <div class="text-md-end footer-links d-none d-md-block">
                      <a href="javascript: void(0);">About</a>
                      <a href="javascript: void(0);">Support</a>
                      <a href="javascript: void(0);">Contact Us</a>
                  </div>
              </div>
          </div>
      </div>
  </footer>
  <!-- end Footer -->
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/layouts/footer.blade.php ENDPATH**/ ?>