<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand mx-auto">
            <a href="/"><img class="img-fluid w-75" src="<?php echo e(asset(env('APP_LOGO_LIGHT'))); ?>" alt="<?php echo e(env('APP_NAME')); ?>"></a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="/"></a>

        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Dashboard</li>
            <li class="<?php echo e(setActiveMenu(['admin.dashboard'])); ?>">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link"><i
                        class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="<?php echo e(setActiveMenu(['admin.user.*'])); ?>">
                <a href="<?php echo e(route('admin.user.index')); ?>" class="nav-link"><i
                        class="fas fa-users"></i><span>Users</span></a>
            </li>
            <li class="<?php echo e(setActiveMenu(['admin.product.*'])); ?>">
                <a href="<?php echo e(route('admin.product.index')); ?>" class="nav-link"><i
                        class="fas fa-box"></i><span>Products</span></a>
            </li>
            <li class="<?php echo e(setActiveMenu(['admin.wallet.*'])); ?>">
                <a href="<?php echo e(route('admin.wallet.index')); ?>" class="nav-link"><i
                        class="fas fa-wallet"></i><span>Wallets</span></a>
            </li>
            <li class="<?php echo e(setActiveMenu(['admin.pricing.*'])); ?>">
                <a href="<?php echo e(route('admin.pricing.index')); ?>" class="nav-link"><i
                        class="fas fa-tag"></i><span>Pricings</span></a>
            </li>
            <li class="dropdown <?php echo e(setActiveMenu(['admin.profile.*', 'admin.general.setting.*'])); ?>">
                <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-cogs"></i>
                    <span>Settings</span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(setActiveMenu(['admin.profile.*'])); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.profile.index')); ?>">Profile</a>
                    </li>
                    <li class="<?php echo e(setActiveMenu(['admin.general.setting.*'])); ?>"><a class="nav-link"
                            href="<?php echo e(route('admin.general.setting.index')); ?>">General Settings</a>
                    </li>
                </ul>
            </li>
        </ul>
    </aside>
</div>
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/admin/layouts/sidebar.blade.php ENDPATH**/ ?>