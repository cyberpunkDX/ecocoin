<div class="greennature-navigation-wrapper">
    <nav class="greennature-navigation" id="greennature-main-navigation">
        <ul id="menu-main-menu-1" class="sf-menu greennature-main-menu">
            <li
                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-5680 current_page_item menu-item-5855menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-5680 current_page_item menu-item-5855 greennature-normal-menu">
                <a href="/register"><i class="fa fa-home"></i>Create Account</a>
            </li>
            
        </ul>
        <a href="login" class="greennature-donate-button"><span
                class="greennature-button-overlay"></span><span
                class="greennature-button-donate-text">Login</span></a>

       
    </nav>
    <div class="greennature-navigation-gimmick" id="greennature-navigation-gimmick"></div>
    <div class="clear"></div>
</div>
<?php /**PATH C:\Users\DX\workspace\laravel\ecocoin\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>