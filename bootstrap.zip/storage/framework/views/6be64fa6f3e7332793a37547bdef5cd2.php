<!-- page loader begin -->
<div class="page-loader">
    <div></div>
    <div></div>
    <div></div>
</div>
<!-- page loader end -->
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/layouts/partials/loader.blade.php ENDPATH**/ ?>