 <!-- section content begin -->
 <div class="uk-section uk-section-muted uk-background-contain uk-background-center in-wave-3"
     style="background-image: url(img/in-wave-background-1.png);" data-uk-parallax="bgy: -200">
     <div class="uk-container">
         <div class="uk-grid-large uk-flex uk-flex-middle" data-uk-grid>
             <div class="uk-width-1-2@m">
                 <img class="uk-margin-bottom" src="img/in-lazy.gif" data-src="img/in-wave-icon-5.svg" alt="wave-icon"
                     width="64" height="64" data-uk-img>
                 <h1 class="uk-margin-remove">Affiliate <span class="in-highlight">insights</span> and<br>investment
                     ideas</h1>
                 <p>Learn from expert analyses and discover high-potential affiliate campaigns to maximize your returns
                     and grow your investment portfolio.</p>
                 <div class="uk-grid-medium uk-child-width-1-2@s uk-child-width-1-3@m uk-text-center uk-margin-medium-top"
                     data-uk-grid>
                     <div>
                         <div class="uk-card uk-card-default uk-card-body uk-border-rounded">
                             <img class="uk-margin-remove-bottom" src="img/in-lazy.gif"
                                 data-src="img/in-wave-icon-6.svg" alt="wave-icon" width="52" height="52"
                                 data-uk-img>
                             <h5 class="uk-margin-small-top">Campaign Strategies</h5>
                         </div>
                     </div>
                     <div>
                         <div class="uk-card uk-card-default uk-card-body uk-border-rounded">
                             <img class="uk-margin-remove-bottom" src="img/in-lazy.gif"
                                 data-src="img/in-wave-icon-7.svg" alt="wave-icon" width="52" height="52"
                                 data-uk-img>
                             <h5 class="uk-margin-small-top">Profit Forecasts</h5>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="uk-width-1-2@m">
                 <div class="uk-inline uk-dark in-wave-video uk-margin-small-bottom">
                     <img class="uk-border-rounded uk-width-1-1" src="img/in-lazy.gif"
                         data-src="img/in-wave-image-1.jpg" alt="wave-video" width="533" height="355" data-uk-img>
                     <div class="uk-position-center" data-uk-lightbox="video-autoplay: true;">
                         <a href="https://www.youtube.com/watch?v=F3QpgXBtDeo" data-attrs="width: 920; height: 517;">
                             <div class="in-play-button"></div>
                             <i class="fas fa-play"></i>
                         </a>
                     </div>
                     <div class="uk-flex-top" data-uk-modal>
                         <div class="uk-modal-dialog uk-width-auto uk-margin-auto-vertical in-iframe">
                             <button class="uk-modal-close-outside" type="button" data-uk-close></button>
                         </div>
                     </div>
                 </div>
                 <p class="uk-text-small uk-text-muted">Master affiliate investing with short online tutorials. <span
                         class="uk-label in-label-small">Sign up</span></p>
             </div>
         </div>
     </div>
 </div>
 <!-- section content end -->
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/partials/welcome/section3.blade.php ENDPATH**/ ?>