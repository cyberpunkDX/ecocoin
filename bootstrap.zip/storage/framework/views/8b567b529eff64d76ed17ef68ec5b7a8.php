<nav class="uk-navbar-container uk-navbar-transparent"
    data-uk-sticky="show-on-up: true; top: 80; animation: uk-animation-fade">
    <div class="uk-container" data-uk-navbar>
        <div class="uk-navbar-left uk-width-expand uk-flex uk-flex-between">
            <a class="uk-navbar-item uk-logo" href="/">
                <img src="<?php echo e(asset(env('APP_LOGO_DARK'))); ?>" alt="logo" width="134" height="23">
            </a>
            <ul class="uk-navbar-nav uk-visible@m">
                <li><a href="/">Home</a>
                </li>
                <li><a href="<?php echo e(route('about.us')); ?>">About Us</a>
                <li><a href="#">Resources<span data-uk-navbar-parent-icon></span></a>
                    <div class="uk-navbar-dropdown uk-navbar-dropdown-width-2">
                        <div class="uk-navbar-dropdown-grid uk-child-width-1-2" data-uk-grid>
                            <div>
                                <ul class="uk-nav uk-navbar-dropdown-nav">
                                    <li><a href="<?php echo e(route('help.center')); ?>">Help Center</a></li>
                                    <li><a href="<?php echo e(route('customer')); ?>">Customers</a></li>
                                    <li><a href="<?php echo e(route('legal.documentation')); ?>">Legal Docs<i class="fas fa-gavel fa-sm"></i></a></li>
                                </ul>
                            </div>
                            <div>
                                <ul class="uk-nav uk-navbar-dropdown-nav">
                                    <li><a class="uk-disabled"
                                            href="<?php echo e(route('legal.documentation')); ?>"><?php echo e(env('APP_DESCRIPTION')); ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="uk-navbar-right uk-width-auto">
            <div class="uk-navbar-item uk-visible@m">
                <div class="in-optional-nav">
                    <a href="<?php echo e(route('login')); ?>" class="uk-button uk-button-text"><i
                            class="fas fa-user-circle uk-margin-small-right"></i>Log in</a>
                    <a href="<?php echo e(route('register')); ?>"
                        class="uk-button uk-button-primary uk-button-small uk-border-pill">Sign up</a>
                </div>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>