<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xxl-9">
            <div class="row">
                <div class="col-xl-4">
                    <div class="card">
                        <div class="d-flex card-header justify-content-between align-items-center">
                            <h4 class="header-title">Total Balance</h4>
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle bg-light-subtle rounded drop-arrow-none card-drop"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="ti ti-dots-vertical"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                  
                                </div>
                            </div>
                        </div>

                        <div class="card-body pt-0">
                            <h2 class="fw-bold"><?php echo e(formatAmount($user->account->balance)); ?> <a href="#!"
                                    class="text-muted"><i class="ti ti-eye"></i></a></h2>

                            <div class="row g-2 mt-2 pt-1">
                                <div class="col">
                                    <a href="<?php echo e(route('user.withdraw.index')); ?>" class="btn btn-primary w-100"><i class="ti ti-coin me-1"></i>
                                        Transfer</a>
                                </div>
                                <div class="col">
                                    <a href="<?php echo e(route('user.deposit.index')); ?>" class="btn btn-info w-100"><i class="ti ti-coin me-1"></i> Deposit</a>
                                </div>
                            </div>
                        </div> <!-- end card-body -->
                    </div> <!-- end card -->
                </div> <!-- end col -->

                <div class="col-xl-4">
                    <div class="card">
                        <div class="card-body">

                            <div class="row justify-content-between">
                                <div class="col-sm-5">
                                    <iconify-icon icon="solar:money-bag-bold-duotone"
                                        class="fs-36 text-muted"></iconify-icon>
                                    <h3 class="mb-0 fw-bold mt-2 mb-1"><?php echo e(formatAmount($user->account->profit)); ?>

                                    </h3>
                                    <p class="text-muted">Total Income</p>
                                    <?php if($roi ): ?>
                                    <span class="badge fs-12 <?php echo e($status === 'success' ? 'badge-soft-success' : 'badge-soft-danger'); ?>"><i class="ti <?php echo e($status === 'success' ? 'ti-arrow-badge-up' : 'ti-arrow-badge-down'); ?>"></i>
                                        <?php echo e($roi); ?>%</span>
                                    <?php endif; ?>
                                    
                                </div> <!-- end col -->

                                <div class="col-sm-7 text-end d-flex flex-column">
                                    <div class="text-end mt-auto">
                                        <div id="revenue-chart" data-colors="#6ac75a"></div>
                                    </div>
                                </div> <!-- end col -->
                            </div>

                        </div> <!-- end card-body -->
                    </div> <!-- end card -->
                </div> <!-- end col -->

                <div class="col-xl-4">
                    <div class="card">
                        <div class="card-body">

                            <div class="row justify-content-between">
                                <div class="col-sm-5">
                                    <iconify-icon icon="solar:hand-money-bold-duotone"
                                        class="fs-36 text-muted"></iconify-icon>
                                    <h3 class="mb-0 fw-bold mt-2 mb-1">
                                        <?php echo e(formatAmount($user->account->expenses)); ?></h3>
                                    <p class="text-muted">Total Expense</p>
                                    
                                </div> <!-- end col -->

                                <div class="col-sm-7 text-end d-flex flex-column">
                                    <div class="text-end mt-auto">
                                        <div id="expenses-chart" data-colors="#465dff"></div>
                                    </div>
                                </div> <!-- end col -->
                            </div>
                        </div> <!-- end card-body -->
                    </div> <!-- end card -->
                </div> 
                <?php if($transactions->count() > 0): ?>
                    <div class="col-12">
                        <div id="curve_chart" style="width: 100%; height: 600px"></div>
                    </div>
                <?php endif; ?>
                
                <!-- end col -->
            </div> <!-- end row -->
            <?php if (isset($component)) { $__componentOriginal40536465f169e6b81e9487c656af22f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal40536465f169e6b81e9487c656af22f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.transactions','data' => ['transactions' => $transactions]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('transactions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['transactions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($transactions)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal40536465f169e6b81e9487c656af22f2)): ?>
<?php $attributes = $__attributesOriginal40536465f169e6b81e9487c656af22f2; ?>
<?php unset($__attributesOriginal40536465f169e6b81e9487c656af22f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40536465f169e6b81e9487c656af22f2)): ?>
<?php $component = $__componentOriginal40536465f169e6b81e9487c656af22f2; ?>
<?php unset($__componentOriginal40536465f169e6b81e9487c656af22f2); ?>
<?php endif; ?>
           
        </div> <!-- end col -->

        <div class="col-xxl-3">
            <div class="row">
                <div class="col-md-6 col-xxl-12">
                    <?php echo $__env->make('dashboard.user.layouts.partials.card-details', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                <div class="col-md-6 col-xxl-12">
                    <div class="card">
                        <div class="card-header d-flex border-bottom border-dashed align-items-center">
                            <h4 class="header-title me-auto">
                                Quick Transfer
                                <i class="ti ti-info-octagon text-muted ms-1" data-bs-toggle="tooltip"
                                    data-bs-placement="top" data-bs-title="This top tooltip is themed via CSS variables.">
                                </i>
                            </h4>
                        </div>

                        <div class="card-body">
                            <?php echo $__env->make('dashboard.user.layouts.partials.bank-transfer-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div> <!-- end card-body-->
                    </div> <!-- end card-->
                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            // Get the raw data as a string and parse it into an array
            var rawData = <?php echo json_encode($chartData); ?>;
            rawData = JSON.parse(rawData); // Convert string to array

            // Debug to confirm
            console.log('Parsed Data:', rawData);
            console.log('Type of Parsed Data:', typeof rawData);

            // Add a dummy point if only one data row exists
            if (rawData.length === 2) {
                var previousMonth = rawData[1][0].replace(/(\d{4})-(\d{2})/, function(match, year, month) {
                    var prevMonth = parseInt(month) - 1;
                    var prevYear = year;
                    if (prevMonth < 1) {
                        prevMonth = 12;
                        prevYear = parseInt(year) - 1;
                    }
                    return `${prevYear}-${prevMonth.toString().padStart(2, '0')}`;
                });
                rawData.splice(1, 0, [previousMonth, 0, 0]);
            }

            var data = google.visualization.arrayToDataTable(rawData);

            var options = {
                title: 'Monthly Income vs Expenses',
                curveType: 'function',
                legend: { position: 'bottom' },
                hAxis: { title: 'Month', format: 'yyyy-MM' },
                vAxis: { title: 'Amount ($)', minValue: 0 },
                pointSize: 5,
                dataOpacity: 1
            };

            var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
            chart.draw(data, options);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.user.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/index.blade.php ENDPATH**/ ?>