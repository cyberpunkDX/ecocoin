<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo e(@$title); ?></h1>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4><?php echo e($title); ?></h4>
                        <?php echo $__env->make('dashboard.admin.partials.account_option', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <img src="<?php echo e(asset($user->image)); ?>" class="img-thumbnail" width="200">
                            </div>
                            <div class="col-12">
                                <dl class="row mb-0">
                                    <dt class="col-12 col-sm-4 fw-bold">Name</dt>
                                    <dd class="col-12 col-sm-8"><?php echo e($user->name); ?></dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Email</dt>
                                    <dd class="col-12 col-sm-8"><?php echo e($user->email); ?></dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Phone</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e($user->dial_code && $user->phone ? $user->dial_code . ' ' . $user->phone : 'Not provided'); ?>

                                    </dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Gender</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e($user->gender ? ucfirst($user->gender) : 'Not specified'); ?></dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Date of Birth</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e(formatDateTime($user->date_of_birth, 'd M Y')); ?>

                                    </dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Currency</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e(currency('name', $user->uuid)); ?>

                                    </dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Balance</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e(formatAmount($user->account->balance, 'symbol', $user->uuid)); ?>

                                    </dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Expenses</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e(formatAmount($user->account->expenses, 'symbol', $user->uuid)); ?>

                                    </dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Profit</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php echo e(formatAmount($user->account->profit, 'symbol', $user->uuid)); ?>

                                    </dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Successful withdrawals</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php if($user->account->successful_withdrawals): ?>
                                            <span class="badge badge-success">Yes</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">No</span>
                                        <?php endif; ?>
                                    </dd>

                                    <dt class="col-12 col-sm-4 fw-bold">Status</dt>
                                    <dd class="col-12 col-sm-8">
                                        <?php if($user->status): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Inactive</span>
                                        <?php endif; ?>
                                    </dd>
                                </dl>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer text-right">
                        <a href="<?php echo e(route('admin.user.edit', $user->uuid)); ?>" class='btn btn-primary'><i
                                class='fa fa-edit'></i> Edit</a>
                        <a href="<?php echo e(route('admin.user.index')); ?>" class='btn btn-secondary'><i
                                class='fa fa-arrow-left'></i>
                            Back</a>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/admin/user/show.blade.php ENDPATH**/ ?>