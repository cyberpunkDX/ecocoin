<form action="<?php echo e(route('user.withdraw.crypto.preview')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row mb-3">
        <div class="col-12">
            <label for="exampleFormControlSelect1" class="form-label">Name</label>
            <select name="user_id" class="form-select" id="exampleFormControlSelect1" aria-label="Default select example">
                <option value=<?php echo e($user->id); ?> selected>
                    <?php echo e($user->name); ?>

                </option>
            </select>
            <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="row mb-2">

        <div class="col-6">
            <div class="form-group">
                <label for="amount" class="form-label">Amount</label>
                <input name="amount" type="text" class="form-control" value="<?php echo e(old('amount')); ?>">
                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label for="address" class="form-label">Crypto</label>
                <input name="wallet_name" type="text" class="form-control" value="<?php echo e(old('wallet_name')); ?>">
                <?php $__errorArgs = ['wallet_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    <div class="row mb-2">
        <div class="col-lg-6">
            <div class="form-group">
                <label for="wallet_address" class="form-label">Wallet
                    address</label>
                <input name="wallet_address" type="text" class="form-control" value="<?php echo e(old('wallet_address')); ?>">
                <?php $__errorArgs = ['wallet_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label for="wallet_address_network" class="form-label">Wallet address network
                    (Optional)</label>
                <input name="wallet_address_network" type="text" class="form-control"
                    value="<?php echo e(old('wallet_address_network')); ?>">
                <?php $__errorArgs = ['wallet_address_network'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <?php if($user->account->deposits->count() > 0): ?>
        <button type="submit" class="btn btn-primary w-100">Proceed</button>
    <?php else: ?>
        <button type="submit" class="btn btn-primary w-100" disabled><i class='bx bxs-lock-alt'></i>
            Deposit to unlock</button>
    <?php endif; ?>
</form>
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/layouts/partials/crypto-withdrawal-form.blade.php ENDPATH**/ ?>