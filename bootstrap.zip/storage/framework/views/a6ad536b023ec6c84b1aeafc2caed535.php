<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo e($title); ?> | <?php echo e(env('APP_NAME')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset(env('APP_FAVICON'))); ?>">

    <!-- Theme Config Js -->
    <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>

    <!-- Vendor css -->
    <link href="<?php echo e(asset('assets/css/vendor.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style" />

    <!-- Icons css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!--- Sweet Alert -->
    <script src="<?php echo e(asset('assets/js/sweet_alert.js')); ?>"></script>
    <style>
        .product-card {
            transition: transform 0.2s;
        }

        .product-card:hover {
            transform: translateY(-5px);
        }

        .cart-count {
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
        }
    </style>
</head>

<body>
    <!-- Begin page -->
    <div class="wrapper">

        <!-- Sidenav Menu Start -->
        <?php echo $__env->make('dashboard.user.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Sidenav Menu End -->

        <!-- Topbar Start -->
        <?php echo $__env->make('dashboard.user.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Topbar End -->

        <!-- Search Modal -->
        <?php echo $__env->make('dashboard.user.layouts.partials.search_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->
        <div class="page-content">
            <div class="page-container">
                <?php echo $__env->make('dashboard.user.components.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->make('partials.sweet_alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('dashboard.user.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->

    </div>
    <!-- END wrapper -->

    <?php echo $__env->make('dashboard.user.layouts.partials.theme_setting', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Vendor js -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>

    <!-- App js -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

    <!-- Apex Chart js -->
    <script src="<?php echo e(asset('assets/vendor/apexcharts/apexcharts.min.js')); ?>"></script>

    <!-- Apex Chart Candlestick Demo js -->
    <script src="<?php echo e(asset('apexcharts/samples/assets/stock-prices.js')); ?>"></script>
    <script src="<?php echo e(asset('apexcharts/samples/assets/series1000.js')); ?>"></script>
    <script src="<?php echo e(asset('apexcharts/samples/assets/github-data.js')); ?>"></script>
    <script src="<?php echo e(asset('apexcharts/samples/assets/irregular-data-series.js')); ?>"></script>

    <!-- Wallet Dashboard js -->
    <script src="<?php echo e(asset('assets/js/pages/dashboard-wallet.js')); ?>"></script>
    
    <?php echo $__env->make('partials.live_chat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/layouts/master.blade.php ENDPATH**/ ?>