 <!-- footer begin -->
 <footer>
     <div class="uk-section uk-section-muted uk-padding-large uk-padding-remove-horizontal uk-margin-medium-top">
         <div class="uk-container">
             <div class="uk-grid-medium" data-uk-grid="">
                 <div class="uk-width-expand@m">
                     <div class="footer-logo">
                         <img class="uk-display-block" src="<?php echo e(env('APP_LOGO_LIGHT')); ?>" alt="footer-logo" width="134"
                             height="23" data-uk-img="">
                     </div>
                     <p class="uk-text-large uk-margin-small-top">Trade with financial thinking.</p>
                     <p class="uk-visible@m">Imperium Tower (Headquarters)<br>
                         Jl. Prof Dr Satrio, Kuningan<br>
                         12920<br>
                         Jakarta - Indonesia
                     </p>
                 </div>
                 <div class="uk-width-3-5@m">
                     <div class="uk-child-width-1-3@s uk-child-width-1-3@m" data-uk-grid="">
                         <div>
                             <h4><span>Markets</span></h4>
                             <ul class="uk-list uk-link-text">
                                 <li><a href="#">Forex</a></li>
                                 <li><a href="#">Synthetic indices</a></li>
                                 <li><a href="#">Stock indices</a></li>
                                 <li><a href="#">Commodities</a></li>
                             </ul>
                         </div>
                         <div>
                             <h4><span>Resources</span></h4>
                             <ul class="uk-list uk-link-text">
                                 <li><a href="#">Help Centre</a></li>
                                 <li><a href="#">Payment methods</a></li>
                             </ul>
                         </div>
                         <div>
                             <h4><span>Company</span></h4>
                             <ul class="uk-list uk-link-text">
                                 <li><a href="#">Our story</a></li>
                                 <li><a href="#">Our leadership</a></li>
                                 <li><a href="#">Contact us</a></li>
                                 <li><a href="#">Partners</a></li>
                             </ul>
                         </div>
                     </div>
                 </div>
                 <div class="uk-width-1-1 uk-margin-large-top in-offset-bottom-10">
                     <h6><i class="fas fa-exclamation-triangle uk-text-danger uk-margin-small-right"></i>Risk
                         warning</h6>
                     <p class="uk-text-small">Investing in affiliate marketing campaigns offers exciting opportunities to grow your wealth, though it’s not without its considerations. The value of your investment may vary over time, and returns can depend on factors like campaign performance and market trends. While past success can provide insight, it’s not a guaranteed predictor of future outcomes. At <?php echo e(config('app.name')); ?>, we strive to maximize your potential for profit through expert strategies and robust tools, though gains are not certain, and some investments may not yield the full amount invested. Withdrawals are processed with care, though timing may vary based on platform policies or external circumstances. We encourage you to explore affiliate marketing with confidence—consider your financial goals, comfort with risk, and the support available to you. For added peace of mind, consult an independent financial advisor to ensure this aligns with your plans. <?php echo e(config('app.name')); ?> is here to guide you every step of the way, though we cannot assume responsibility for market-driven losses.</a></p>
                     <hr>
                 </div>
             </div>
         </div>
         <div class="uk-section uk-section-secondary uk-padding-remove-vertical">
             <div class="uk-container">
                 <div class="uk-grid">
                     <div class="uk-width-3-4@m uk-visible@m">
                         <ul class="uk-subnav uk-subnav-divider">
                             <li><a href="#">Regulations</a></li>
                             <li><a href="#">Legal documents</a></li>
                             <li><a href="#">Important information</a></li>
                             <li><a href="#">Privacy</a></li>
                             <li><a href="#">Public relations</a></li>
                             <li><a href="#">Careers</a></li>
                         </ul>
                     </div>
                     <div class="uk-width-expand@m uk-text-right@m">
                         <p class="copyright-text">© <?php echo e(date('Y')); ?> <?php echo e(env('APP_NAME')); ?>.</p>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     </div>
 </footer>
 <!-- footer end -->
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/layouts/footer.blade.php ENDPATH**/ ?>