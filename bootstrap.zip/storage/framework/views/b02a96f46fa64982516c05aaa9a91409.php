<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; <?php echo e(date('Y')); ?> <div class="bullet"></div> Design By <a
            href="<?php echo e(env('APP_URL')); ?>"><?php echo e(env('APP_NAME')); ?></a>
    </div>
    <div class="footer-right">

    </div>
</footer>
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/admin/layouts/footer.blade.php ENDPATH**/ ?>