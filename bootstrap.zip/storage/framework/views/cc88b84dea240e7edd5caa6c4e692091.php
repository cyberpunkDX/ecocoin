
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/partials/live_chat.blade.php ENDPATH**/ ?>