<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1><?php echo e(@$title); ?></h1>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4><?php echo e($title); ?></h4>
                        <div class="card-header-action">
                            <a href="<?php echo e(route('admin.wallet.create')); ?>" class="btn btn-primary">Add Wallet</a>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="table-1">
                                <thead>
                                    <tr>
                                        <th>
                                            #
                                        </th>
                                        <th>Name</th>
                                        <th>Address</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><a
                                                    href="<?php echo e(route('admin.wallet.show', $wallet->uuid)); ?>"><?php echo e($wallet->name); ?></a>
                                            </td>
                                            <td>
                                                <?php echo e($wallet->address); ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.wallet.show', $wallet->uuid)); ?>"
                                                    class='btn btn-info m-2'><i class='fa fa-eye'></i></a>
                                                <a href="<?php echo e(route('admin.wallet.edit', $wallet->uuid)); ?>"
                                                    class='btn btn-primary'><i class='fa fa-edit'></i></a>
                                                <a href="<?php echo e(route('admin.wallet.delete', $wallet->uuid)); ?>"
                                                    onclick="return confirm('Are you sure?')" class='btn btn-danger m-2'><i
                                                        class='fa fa-trash'></i></a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/admin/wallet/index.blade.php ENDPATH**/ ?>