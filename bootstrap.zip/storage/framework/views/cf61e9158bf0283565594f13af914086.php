
<?php $__env->startSection('content'); ?>

    <body>
        <div class="container mt-5 mb-5">
            <h1 class="text-center mb-4">User Profile</h1>

            <div class="row justify-content-center">
                <div class="col-md-8">
                    <!-- Profile Card -->
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <div class="row">
                                <!-- Profile Picture -->
                                <div class="col-md-4 text-center mb-3 mb-md-0">
                                    <img src="<?php echo e($user->profile_picture ?? 'https://via.placeholder.com/150'); ?>"
                                        alt="Profile Picture" class="profile-img img-fluid mb-3">
                                    <h5 class="card-title"><?php echo e($user->name); ?></h5>
                                    <p class="text-muted"><?php echo e($user->email); ?></p>
                                </div>

                                <!-- Profile Details -->
                                <div class="col-md-8">
                                    <h5 class="mb-3">About Me</h5>
                                    <p><?php echo e($user->bio ?? 'No bio provided.'); ?></p>

                                    <hr>

                                    <h5 class="mb-3">Details</h5>
                                    <dl class="row mb-0">
                                        <dt class="col-sm-4">Country:</dt>
                                        <dd class="col-sm-8"><?php echo e($user->country ?? 'N/A'); ?></dd>

                                        <dt class="col-sm-4">Joined:</dt>
                                        <dd class="col-sm-8"><?php echo e($user->created_at->format('F j, Y')); ?></dd>

                                        <dt class="col-sm-4">Location:</dt>
                                        <dd class="col-sm-8"><?php echo e($user->location ?? 'Not specified'); ?></dd>

                                        <dt class="col-sm-4">Account Balance:</dt>
                                        <dd class="col-sm-8">$<?php echo e(number_format($user->account->balance ?? 0, 2)); ?></dd>
                                    </dl>
                                </div>
                            </div>
                        </div>

                        <!-- Card Footer with Actions -->
                        <div class="card-footer d-flex text-center">
                            <a href="<?php echo e(route('user.profile.update')); ?>" class="btn btn-primary me-2">Edit Profile</a>
                            <a href="<?php echo e(route('user.dashboard')); ?>" class="btn btn-outline-secondary">Back to Dashboard</a>
                        </div>
                    </div>

                    <!-- Additional Info (e.g., Recent Activity) -->

                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.user.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/profile/index.blade.php ENDPATH**/ ?>