
<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__currentLoopData = $pricings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- First pricing -->
            <div class="col-lg-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo e($pricing->name); ?></h4>
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <td>Minimum Capital:</td>
                                    <td>USD<?php echo e($pricing->minimum); ?></td>
                                </tr>
                                <tr>
                                    <td>Maximum Capital:</td>
                                    <td>USD<?php echo e($pricing->maximum); ?></td>
                                </tr>

                                <tr>
                                    <td>Profit Withdrawal:</td>
                                    <td>Yes</td>
                                </tr>
                                <tr>
                                    <td>ROI:</td>
                                    <td>Yes</td>
                                </tr>
                                <tr>
                                    <td>Money Back:</td>
                                    <td>Yes</td>
                                </tr>
                            </tbody>
                        </table>
                        <form action="<?php echo e(route('user.deposit.index')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="amount" value="<?php echo e($pricing->minimum); ?>">
                            <button type="submit" class="btn btn-success w-100">Activate</button>
                        </form>
                            

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div><?php echo e($pricings->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.user.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/pricing/index.blade.php ENDPATH**/ ?>