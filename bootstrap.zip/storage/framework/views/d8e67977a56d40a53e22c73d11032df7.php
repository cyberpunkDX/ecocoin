<form action="<?php echo e(route('user.withdraw.bank.preview')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row mb-3">
        <div class="col-12">
            <label for="exampleFormControlSelect1" class="form-label">Account
                Name</label>

            <input type="text" name="account_name" class="form-control" value="<?php echo e($user->name); ?>" id="">
            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
            <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="row mb-2">
        <div class="col-12">
            <div class="form-group">
                <label for="amount" class="form-label">Amount</label>
                <input name="amount" type="text" class="form-control" value="<?php echo e(old('amount')); ?>">
                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    <div class="row mb-2">
        <div class="col-lg-6">
            <div class="form-group">
                <label for="account_number" class="form-label">Account
                    Number</label>
                <input name="account_number" type="text" class="form-control" value="<?php echo e(old('account_number')); ?>">
                <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group">
                <label for="bank_name" class="form-label">Bank Name
                </label>
                <input name="bank_name" type="text" class="form-control" value="<?php echo e(old('bank_name')); ?>">
                <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="form-group">
                <label for="routing_number" class="form-label">Bank
                    Routing
                    Number (optional)</label>
                <input name="routing_number" type="text" class="form-control" value="<?php echo e(old('routing_number')); ?>">
                <?php $__errorArgs = ['routing_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

    </div>
    <div class="row g-2 mt-3">
        <div class="col">

            <?php if($user->account->deposits->count() > 0): ?>
                <button type="submit" class="btn btn-primary w-100">Send Money</button>
            <?php else: ?>
                <button disabled type="submit" class="btn btn-primary w-100">Insufficient
                    Balance</button>
            <?php endif; ?>

        </div>
        <div class="col">
            <a href="#!" class="btn btn-outline-info w-100">Save as Draft</a>
        </div>
    </div>
</form>
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/layouts/partials/bank-transfer-form.blade.php ENDPATH**/ ?>