 <!-- section content begin -->
 <div class="uk-section in-wave-2">
     <div class="uk-container">
         <div class="uk-grid">
             <div class="uk-width-3-4@m">
                 <h1 class="uk-margin-remove-bottom">Industry-<span class="in-highlight">leading</span> affiliate returns
                 </h1>
                 <p class="uk-text-lead uk-text-muted uk-margin-small-top uk-margin-bottom">Invest in high-performing
                     affiliate marketing campaigns with top experts and watch your profits grow effortlessly.</p>
             </div>
         </div>
         <div class="uk-grid-medium uk-grid-match" data-uk-grid>
             <div class="uk-width-1-2@s uk-width-1-4@m">
                 <div class="uk-card uk-card-default uk-card-body uk-border-rounded uk-background-contain uk-background-bottom-center"
                     style="background-image: url(img/in-wave-card-bg-1.png);">
                     <h5 class="uk-margin-remove">
                        E-commerce <i class="fas fa-chevron-right fa-xs"></i>
                     </h5>
                     <p class="uk-margin-remove">Returns up to</p>
                     <h1 class="uk-margin-top">15%</h1>
                     <p class="uk-margin-remove-top uk-margin-bottom">monthly</p>
                     <p>Invest in affiliate campaigns promoting top e-commerce products with high conversion rates.</p>
                 </div>
             </div>
             <div class="uk-width-1-2@s uk-width-1-4@m">
                 <div class="uk-card uk-card-default uk-card-body uk-border-rounded uk-background-contain uk-background-bottom-center"
                     style="background-image: url(img/in-wave-card-bg-2.png);">
                     <h5 class="uk-margin-remove">
                        Tech Offers <i class="fas fa-chevron-right fa-xs"></i>
                     </h5>
                     <p class="uk-margin-remove">Returns from</p>
                     <h1 class="uk-margin-top">12%</h1>
                     <p class="uk-margin-remove-top uk-margin-bottom">monthly</p>
                     <p>Fund affiliate promotions for cutting-edge tech products with expert-managed strategies.</p>
                 </div>
             </div>
             <div class="uk-width-1-2@s uk-width-1-4@m">
                 <div class="uk-card uk-card-default uk-card-body uk-border-rounded uk-background-contain uk-background-bottom-center"
                     style="background-image: url(img/in-wave-card-bg-3.png);">
                     <h5 class="uk-margin-remove">
                        Health & Wellness <i class="fas fa-chevron-right fa-xs"></i>
                     </h5>
                     <p class="uk-margin-remove">Returns from</p>
                     <h1 class="uk-margin-top">10%</h1>
                     <p class="uk-margin-remove-top uk-margin-bottom">monthly</p>
                     <p>Support campaigns in the booming health & wellness niche with consistent profit growth.</p>
                 </div>
             </div>
             <div class="uk-width-1-2@s uk-width-1-4@m">
                 <div class="uk-card uk-card-default uk-card-body uk-border-rounded uk-background-contain uk-background-bottom-center"
                     style="background-image: url(img/in-wave-card-bg-4.png);">
                     <h5 class="uk-margin-remove">
                        Lifestyle <i class="fas fa-chevron-right fa-xs"></i>
                     </h5>
                     <p class="uk-margin-remove">Returns as high as</p>
                     <h1 class="uk-margin-top">18%</h1>
                     <p class="uk-margin-remove-top uk-margin-bottom">monthly</p>
                     <p>Invest in lifestyle affiliate campaigns with premium offers and expert optimization.</p>
                 </div>
             </div>
         </div>
         <div class="uk-grid uk-flex uk-flex-center">
             <div class="uk-width-3-5@m">
                 <div
                     class="uk-card uk-card-default uk-card-body uk-text-center uk-border-rounded uk-box-shadow-small in-wave-2-card">
                     <span class="uk-label in-label-small uk-text-uppercase uk-margin-small-right">Start
                         investing</span>
                     Join thousands of investors growing their wealth with affiliate marketing. <a href="<?php echo e(route('register')); ?>">Sign
                         up now!</a>
                 </div>
                 <div class="uk-grid-collapse uk-grid-divider uk-child-width-1-3@s uk-child-width-1-3@m uk-text-center uk-margin-top uk-margin-small-bottom"
                     data-uk-grid>
                     <div>
                         <i class="fas fa-headset fa-lg uk-margin-small-right uk-text-primary"></i>
                         <p class="uk-margin-remove uk-text-small uk-text-uppercase">Expert support</p>
                     </div>
                     <div>
                         <i class="fas fa-university fa-lg uk-margin-small-right uk-text-primary"></i>
                         <p class="uk-margin-remove uk-text-small uk-text-uppercase">Trusted platform</p>
                     </div>
                     <div>
                         <i class="fas fa-history fa-lg uk-margin-small-right uk-text-primary"></i>
                         <p class="uk-margin-remove uk-text-small uk-text-uppercase">Proven results</p>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <!-- section content end -->
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/partials/welcome/section2.blade.php ENDPATH**/ ?>