
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Your Investments</h2>
    <?php $__currentLoopData = auth()->user()->investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-body">
                <h5><?php echo e($investment->product->name); ?></h5>
                <p>Invested: $<?php echo e(number_format($investment->amount, 2)); ?></p>
                <p>ROI: <?php echo e($investment->roi); ?>% after <?php echo e($investment->duration); ?> days</p>
                <p>End Date: <?php echo e($investment->end_date); ?></p>
                <p>Status: <?php echo e($investment->is_completed ? 'Completed' : 'Active'); ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.user.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/dashboard/user/investment/index.blade.php ENDPATH**/ ?>