<!-- to top begin -->
<a href="#" class="to-top uk-visible@m" data-uk-scroll>
    Top<i class="fas fa-chevron-up"></i>
</a>
<!-- to top end -->
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/layouts/partials/to_top.blade.php ENDPATH**/ ?>