<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 col-sm-12 mx-auto">
            <div class="uk-section uk-padding-remove-vertical mt-5 mb-5">
                <div class="uk-container uk-container-expand">
                    <div class="uk-grid" data-uk-height-viewport="expand: true">

                        <div class="uk-width-expand@m uk-flex uk-flex-middle">
                            <div class="uk-grid uk-flex-center">
                                <div class="uk-width-3-5@m">
                                    <div class="uk-text-center in-padding-horizontal@s">
                                        <a class="uk-logo" href="/">
                                            <img src="img/in-lazy.gif" data-src="<?php echo e(env('APP_LOGO_LIGHT')); ?>" alt="logo"
                                                width="134" height="23" data-uk-img>
                                        </a>
                                        <?php if(session('status')): ?>
                                            <p class="text-success"> <?php echo e(session('status')); ?></p>
                                        <?php endif; ?>
                                        <div class="text-left mt-4">
                                            <h1 class="uk-text-lead uk-margin-small-top uk-margin-medium-bottom">
                                                <?php echo e($title); ?></h1>
                                        </div>
                                        <?php echo $__env->make('partials.validation_message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <form class="uk-grid uk-form" method="POST" action="<?php echo e(route('register')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="uk-margin-small uk-width-1-1 uk-inline">
                                                <span class="uk-form-icon uk-form-icon-flip fas fa-user fa-sm"></span>
                                                <input class="uk-input uk-border-rounded" name="name"
                                                    value="<?php echo e(old('name')); ?>" id="name" value="" type="name"
                                                    placeholder="Full Name">
                                                <?php if($errors->has('name')): ?>
                                                    <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                                                <?php endif; ?>
                                            </div>
                                            <div class="uk-margin-small uk-width-1-1 uk-inline">
                                                <span class="uk-form-icon uk-form-icon-flip fas fa-envelope fa-sm"></span>
                                                <input class="uk-input uk-border-rounded" name="email"
                                                    value="<?php echo e(old('email')); ?>" id="email" value="" type="email"
                                                    placeholder="Email Address">
                                                <?php if($errors->has('email')): ?>
                                                    <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                                                <?php endif; ?>
                                            </div>
                                            <div class="uk-margin-small uk-width-1-1 uk-inline">
                                                <span class="uk-form-icon uk-form-icon-flip fas fa-lock fa-sm"></span>
                                                <input class="uk-input uk-border-rounded" name="password"
                                                    value="<?php echo e(old('password')); ?>" id="password" value=""
                                                    type="password" placeholder="Password ">
                                                <?php if($errors->has('password')): ?>
                                                    <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                                                <?php endif; ?>
                                            </div>
                                            <div class="uk-margin-small uk-width-1-1 uk-inline">
                                                <span class="uk-form-icon uk-form-icon-flip fas fa-lock fa-sm"></span>
                                                <input class="uk-input uk-border-rounded" name="password_confirmation"
                                                    value="<?php echo e(old('password_confirmation')); ?>" id="password_confirmation"
                                                    value="" type="password" placeholder="Confirm Password">
                                                <?php if($errors->has('password_confirmation')): ?>
                                                    <p class="text-danger"><?php echo e($errors->first('password_confirmation')); ?>

                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-12">
                                                <button type="submit"
                                                    class="uk-button uk-width-1-1 uk-button-primary uk-border-rounded uk-float-left">
                                                    Create account
                                                </button>

                                            </div>
                                        </form>
                                        <!-- login form end -->
                                        <p class="uk-heading-line"><span>Or register with</span></p>
                                        <div class="uk-margin-medium-bottom">
                                            <a class="uk-button uk-button-primary uk-button-small uk-border-rounded color-google"
                                                href="<?php echo e(route('socialite.redirect', 'google')); ?>"><i
                                                    class="fab fa-google uk-margin-small-right"></i>Google</a>
                                            <a class="uk-button uk-button-primary uk-button-small uk-border-rounded uk-margin-small-left color-facebook"
                                                href="<?php echo e(route('socialite.redirect', 'github')); ?>"><i
                                                    class="fab fa-github uk-margin-small-right"></i>GitHub</a>
                                        </div>
                                    </div>
                                    <div class="text-center mt-3">
                                        <p class="mt-15 mb-0">Already have an account? <a href="<?php echo e(route('login')); ?>"
                                                class="text-warning">Login account</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/auth/register.blade.php ENDPATH**/ ?>