<!-- header begin -->
<header>
    <div class="uk-section uk-padding-remove-vertical in-header-inverse ">
        <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="uk-container">
            <div class="uk-grid">
                <div class="uk-width-1-1">
                    <div class="uk-card uk-card-secondary uk-card-small uk-card-body uk-border-rounded">
                        <div class="uk-grid uk-text-small" data-uk-grid>
                            <div class="uk-width-3-4@m uk-visible@m">
                                <p>
                                    <?php echo e(env('APP_DESCRIPTION')); ?>

                                </p>
                            </div>
                            <div class="uk-width-expand@m uk-text-center uk-text-right@m">
                                <a class="uk-margin-right" href="#"><i
                                        class="fas fa-comment-alt uk-margin-small-right"></i>Live Chat</a>
                                <a href="#"><i
                                        class="fas fa-phone-alt uk-margin-small-right uk-margin-small-left"></i><?php echo e(env('APP_PHONE')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- header end -->
<?php /**PATH C:\Users\DX\workspace\laravel\affiliate_broker\resources\views/layouts/header.blade.php ENDPATH**/ ?>