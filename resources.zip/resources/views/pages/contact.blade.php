@extends('layouts.master')
@section('content')
    <!-- section content begin -->
    <div class="page-wrapper overflow-hidden">

        <!--  Banner Section -->
        <section class="banner-section banner-inner-section position-relative overflow-hidden d-flex align-items-end"
            style="background-image: url({{ asset('home/images/backgrounds/blog-banner.jpg') }});">
            <div class="container">
                <div class="d-flex flex-column gap-4 pb-5 pb-xl-10 position-relative z-1">
                    <div class="row align-items-center">
                        <div class="col-xl-8">
                            <div class="d-flex align-items-center gap-4" data-aos="fade-up" data-aos-delay="100"
                                data-aos-duration="1000">
                                <img src="home/images/svgs/primary-leaf.svg" alt=""
                                    class="img-fluid animate-spin">
                                <p class="mb-0 text-white fs-5 text-opacity-70">We'd love to hear from you. <span
                                        class="text-primary">Get in touch</span> with us for any questions, feedback, or partnership opportunities.</p>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex align-items-end gap-3" data-aos="fade-up" data-aos-delay="200"
                        data-aos-duration="1000">
                        <h1 class="mb-0 fs-16 text-white lh-1">Contact Us</h1>
                        <a href="javascript:void(0)" class="p-1 ps-7 bg-primary rounded-pill">
                            <span class="bg-white round-52 rounded-circle d-flex align-items-center justify-content-center">
                                <iconify-icon icon="lucide:arrow-up-right" class="fs-8 text-dark"></iconify-icon>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!--  Get in touch Section -->
        <section class="get-in-touch py-5 py-lg-11 py-xl-12">
        <div class="container">
            <div class="d-flex flex-column gap-5 gap-xl-10">
            <div class="row gap-7 gap-xl-0">
                <div class="col-xl-4 col-xxl-4">
                <div class="d-flex align-items-center gap-7 py-2" data-aos="fade-right" data-aos-delay="100"
                    data-aos-duration="1000">
                    <span
                    class="round-36 flex-shrink-0 text-dark rounded-circle bg-primary hstack justify-content-center fw-medium">01</span>
                    <hr class="border-line bg-white">
                    <span class="badge text-bg-dark">Contact us</span>
                </div>
                </div>
                <div class="col-xl-8 col-xxl-7">
                <div class="row">
                    <div class="col-xxl-8">
                    <div class="d-flex flex-column gap-6" data-aos="fade-up" data-aos-delay="100"
                        data-aos-duration="1000">
                        <h2 class="mb-0">Get in touch</h2>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            <div class="row justify-content-between gap-7 gap-xl-0">
                <div class="col-xl-3">
                <p class="mb-0 fs-5" data-aos="fade-right" data-aos-delay="100" data-aos-duration="1000">Let’s collaborate
                    and create something amazing! Tell me about your project—I’m all
                    ears.</p>
                </div>
                <div class="col-xl-8">
                <form class="d-flex flex-column gap-7" data-aos="fade-up" data-aos-delay="200" data-aos-duration="1000">
                    <div>
                    <input type="text" class="form-control border-bottom border-dark" id="formGroupExampleInput"
                        placeholder="Name">
                    </div>
                    <div>
                    <input type="email" class="form-control border-bottom border-dark" id="exampleInputEmail1"
                        placeholder="Email" aria-describedby="emailHelp">
                    </div>
                    <div>
                    <textarea class="form-control border-bottom border-dark" id="exampleFormControlTextarea1"
                        placeholder="Tell us about your project" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn w-100 justify-content-center">
                    <span class="btn-text">Submit message</span>
                    <iconify-icon icon="lucide:arrow-up-right"
                        class="btn-icon bg-white text-dark round-52 rounded-circle hstack justify-content-center fs-7 shadow-sm"></iconify-icon>
                    </button>
                </form>
                </div>
            </div>
            </div>
        </div>
        </section>

    </div>
@endsection
