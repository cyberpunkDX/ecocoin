<?php

require_once __DIR__ . '/frontend.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/socialite.php';
require_once __DIR__ . '/master.php';
require_once __DIR__ . '/admin.php';
require_once __DIR__ . '/user.php';
